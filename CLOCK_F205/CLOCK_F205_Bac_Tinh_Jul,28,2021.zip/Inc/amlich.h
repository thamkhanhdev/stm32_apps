
void am_lich(unsigned char SolarDay, unsigned char SolarMonth, unsigned int SolarYear,char* ngay_al,char* thang_al);

#define BEGINNING_YEAR	2017



