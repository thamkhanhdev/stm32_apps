#include "stdint.h"

/* 256-step brightness table: gamma = 2.2 */
extern const uint8_t gamma_table[];

extern const uint8_t gammaR[256];
/* 256-step brightness table: gamma = 2.2 */
extern const uint8_t gammaG[256];
/* 256-step brightness table: gamma = 2.2 */
extern const uint8_t gammaB[256];
