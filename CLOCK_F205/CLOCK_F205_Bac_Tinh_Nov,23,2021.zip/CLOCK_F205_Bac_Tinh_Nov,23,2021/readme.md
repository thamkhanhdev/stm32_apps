1. CLOCK_F205_17h20Apr,11,2020
    - Worked with RGB565 video AVI uncompressed without audio.