/*================================================================================================*/
/**
*   @file       matrix.c
*   @author     Khanh Tham
*   @contact    thamkhanhdev@gmail.com
*   @version    1.0.0
*
*   @brief      Matrix program body.
*   @details    This is a demo application showing the usage of the API.
*
*   This file contains sample code only. It is not part of the production code deliverables.
*
*   @addtogroup BUILD_ENV_COMPONENT
*   @{
*/
/*==================================================================================================
*   Project              : Full color - Rgb matrix pannel
*   Platform             : STM32H750xxx
*
*   SW Version           : 1.0.0
*   Build Version        : Reserved
*
*   Copyright 2020 ST Semiconductor, Inc.
*   All Rights Reserved.
==================================================================================================*/
#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "matrix.h"
#include "gamma.h"
#include "gfxfont.h"
#include "TomThumb.h"
#include "FreeSerifBoldItalic18pt7b.h"
#include "FreeSansOblique9pt7b.h"
#include "FreeSerif9pt7b.h"
/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/
#define CALLOVERHEAD    15U   // Actual value measured = 56
#define LOOPTIME        30U  // Actual value measured = 188
#define IRQ_TIMEDELAY   50UL

/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/

// static uint16_t const gTimeCount[8]={10, 20, 40, 80, 160, 240, 320}; // he so chia nap vao timer ok with 256x64 47.9Hz
// static uint16_t const gTimeCount[8]={15, 30, 60, 120, 160, 240, 320}; // he so chia nap vao timer ok with 256x64 47.9Hz
uint16_t const gTimeCount[8]={20, 40, 80, 160, 320, 640, 480, 600}; // he so chia nap vao timer ok with 256x64 47.9Hz
// uint16_t const gTimeCount[8]={ 40, 80, 160, 240, 360, 480, 600, 1000}; // he so chia nap vao timer ok with 256x64 47.9Hz
// uint16_t const gTimeCount[8]={ 160, 240, 360, 480, 600, 1000, 1500}; // he so chia nap vao timer ok with 256x64 47.9Hz

static const int8_t sinetab[256] = {
     0,   2,   5,   8,  11,  15,  18,  21,
    24,  27,  30,  33,  36,  39,  42,  45,
    48,  51,  54,  56,  59,  62,  65,  67,
    70,  72,  75,  77,  80,  82,  85,  87,
    89,  91,  93,  96,  98, 100, 101, 103,
   105, 107, 108, 110, 111, 113, 114, 116,
   117, 118, 119, 120, 121, 122, 123, 123,
   124, 125, 125, 126, 126, 126, 126, 126,
   127, 126, 126, 126, 126, 126, 125, 125,
   124, 123, 123, 122, 121, 120, 119, 118,
   117, 116, 114, 113, 111, 110, 108, 107,
   105, 103, 101, 100,  98,  96,  93,  91,
    89,  87,  85,  82,  80,  77,  75,  72,
    70,  67,  65,  62,  59,  56,  54,  51,
    48,  45,  42,  39,  36,  33,  30,  27,
    24,  21,  18,  15,  11,   8,   5,   2,
     0,  -3,  -6,  -9, -12, -16, -19, -22,
   -25, -28, -31, -34, -37, -40, -43, -46,
   -49, -52, -55, -57, -60, -63, -66, -68,
   -71, -73, -76, -78, -81, -83, -86, -88,
   -90, -92, -94, -97, -99,-101,-102,-104,
  -106,-108,-109,-111,-112,-114,-115,-117,
  -118,-119,-120,-121,-122,-123,-124,-124,
  -125,-126,-126,-127,-127,-127,-127,-127,
  -128,-127,-127,-127,-127,-127,-126,-126,
  -125,-124,-124,-123,-122,-121,-120,-119,
  -118,-117,-115,-114,-112,-111,-109,-108,
  -106,-104,-102,-101, -99, -97, -94, -92,
   -90, -88, -86, -83, -81, -78, -76, -73,
   -71, -68, -66, -63, -60, -57, -55, -52,
   -49, -46, -43, -40, -37, -34, -31, -28,
   -25, -22, -19, -16, -12,  -9,  -6,  -3
};

/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/
/**
 * @brief Number of multiplexed rows; actual MATRIX_HEIGHT is 2X this.
 */
static uint8_t gRows = 0U;
// static uint8_t gRows = 0;

/**
 * @brief The actual postion bit is handling.
 */
static uint8_t gBitPos = 0U;
// static uint8_t gBitPos = 0;

/**
 * @brief The current brightness value
 */
static uint8_t gBrightness;
static bool gCp437 = false;
static uint32_t gCountBit = 0UL;
#ifdef RECORD_LAST_FRAME
#if 16U==MATRIX_SCANRATE
static uint16_t gRecordFrame[MATRIX_WIDTH/MATRIX_SCANRATE][MATRIX_HEIGHT][2] = {0UL};
#elif 32U==MATRIX_SCANRATE
static uint32_t gRecordFrame[MATRIX_WIDTH/MATRIX_SCANRATE][MATRIX_HEIGHT][2] = {0UL};
#endif /* 16U==MATRIX_SCANRATE */
static uint8_t  gCurrFrame = 0U;
#if 16U==MATRIX_SCANRATE
static const uint16_t gBitMask[MATRIX_SCANRATE] =
#elif 32U==MATRIX_SCANRATE
static const uint32_t gBitMask[MATRIX_SCANRATE] =
#endif /* 16U==MATRIX_SCANRATE */
{
    0x1,
    0x2,
    0x4,
    0x8,
    0x10,
    0x20,
    0x40,
    0x80,
    0x100,
    0x200,
    0x400,
    0x800,
    0x1000,
    0x2000,
    0x4000,
    0x8000,
#if 32U==MATRIX_SCANRATE
    0x10000,
    0x20000,
    0x40000,
    0x80000,
    0x100000,
    0x200000,
    0x400000,
    0x800000,
    0x1000000,
    0x2000000,
    0x4000000,
    0x8000000,
    0x10000000,
    0x20000000,
    0x40000000,
    0x80000000,
#endif /* #if 32U==MATRIX_SCANRATE */
};
#endif /* #ifdef RECORD_LAST_FRAME */
#ifdef USE2BUS
static uint16_t gBuff[MATRIX_WIDTH*MATRIX_HEIGHT*MAX_BIT/4];
#else
// static uint8_t gBuff[MATRIX_WIDTH*MATRIX_HEIGHT*MAX_BIT/2];
static uint16_t gBuff[MATRIX_WIDTH*MATRIX_HEIGHT];
#endif /* #ifdef USE2BUS */
static uint16_t gCursorX = 0U;
static uint16_t gCursorY = 0U;
static uint8_t  gTextSizeX = 1U;
static uint8_t  gTextSizeY = 1U;
// static GFXfont *gfxFont = &TomThumb;       ///< Pointer to special font
static const GFXfont *gfxFont = NULL;       ///< Pointer to special font
/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/

/**
  * @brief The array store image data.
  */
extern const uint8_t gImage_test[];

/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
/**
 * The C library function int vsprintf(char *str, const char *format, va_list arg)
 * sends formatted output to a string using an argument list passed to it.
 */
int vsprintf(char *str, const char *format, va_list arg);

/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/
static inline uint8_t * pgm_read_bitmap_ptr( const GFXfont *gfxFont )
{
    return (uint8_t *) pgm_read_pointer( &gfxFont->bitmap );
}

static inline GFXglyph * pgm_read_glyph_ptr(const GFXfont *gfxFont, uint8_t c)
{
    return &(((GFXglyph *)pgm_read_pointer(&gfxFont->glyph))[c]);
}

inline static void MATRIX_Vprint( MATRIX_FontTypes nFontType, uint16_t u16Color, const char *fmt, va_list argp )
{
    char string[200];
    if(0 < vsprintf(string,fmt,argp)) // build string
    {
        MATRIX_Print( (uint8_t *) string, nFontType, u16Color );
    }
}
/**
 * @brief   Write a pixel, overwrite in subclasses if startWrite is defined!
 * @details
 *          Write a pixel, overwrite in subclasses if startWrite is defined,
 *          For example scan with 5bit per color per pixel
 *          For each | w | instance, they store MATRIX_HEIGHT pixels.
 *          |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |
 *          | b0 | b1 | b2 | b3 | b4 | b0 | b1 | b2 | b3 | b4 | b0 | b1 | b2 | b3 | b4 |
 *          |---------- r0 ----------|---------- r1 ----------|---------- r2 ----------|
 *          Total elements are MATRIX_WIDTH * MATRIX_HEIGHT * MAX_BIT. Actual only need to scan a half
 *          part of one matrix.
 *
 * @param   x   x coordinate
 * @param   y   y coordinate
 * @param   color 16-bit 5-6-5 Color to fill with
 *
 * @retval  StdReturnType
 *          E_OK: Write a pexel successfully.
 *          E_NOT_OK Otherwise.
 */
 static inline void MATRIX_DrawPixel( uint16_t x, uint16_t y, uint16_t c )
{
    uint32_t _curPos;
    uint8_t r, g, b;
    uint16_t bit, limit;
    if( (x < 0) || (x >= MATRIX_WIDTH) || (y < 0) || (y >= MATRIX_HEIGHT) )
    {
        return;
    }

#if defined(RGB888)
    r = (uint8_t) ((c >> 16) & 0xFF); /* RRRRRRRRggggggggbbbbbbbb */
    g = (uint8_t) ((c >>  8) & 0xFF); /* rrrrrrrrGGGGGGGGbbbbbbbb */
    b = (uint8_t) ((c >>  0) & 0xFF); /* rrrrrrrrggggggggBBBBBBBB */
#elif defined(RGB666)
    r = (uint8_t) ((c >> 12) & 0x3F); /* RRRRRRggggggbbbbbb */
    g = (uint8_t) ((c >>  6) & 0x3F); /* rrrrrrGGGGGGbbbbbb */
    b = (uint8_t) ((c >>  0) & 0x3F); /* rrrrrrggggggBBBBBB */
#elif defined(RGB565)
    r = (uint8_t) ((c >> 11) & 0x1F); /* RRRRRggggggbbbbb */
    g = (uint8_t) ((c >>  6) & 0x3F); /* rrrrrGGGGGGbbbbb */
    b = (uint8_t) ((c >>  0) & 0x1F); /* rrrrrggggggBBBBB */
#elif defined(RGB555)
    r = (uint8_t) ((c >> 10) & 0x1F); /* RRRRRgggggbbbbb */
    g = (uint8_t) ((c >>  5) & 0x1F); /* rrrrrGGGGGbbbbb */
    b = (uint8_t) ((c >>  0) & 0x1F); /* rrrrrgggggBBBBB */
#elif defined(RGB444) /* RGB565 -> RGB444 */
    r = (uint8_t) ((c >>  12) & 0xF);  /* RRRRrggggggbbbbb */
    g = (uint8_t) ((c >>   7) & 0xF);  /* rrrrrGGGGggbbbbb */
    b = (uint8_t) ((c >>   1) & 0xF);  /* rrrrrggggggBBBBb */
#elif defined(RGB333)
#endif

    bit   = 1;
    limit = 1 << MAX_BIT;

#if 0
    /* Fill data to the second bus if used */
#ifdef USE2BUS
    if( y >= MATRIX_HEIGHT/2 )
    {
        /* Minus by MATRIX_HEIGHT/2 */
        y = y - MATRIX_HEIGHT/2 ;

        if( y < MATRIX_SCANRATE )
        {
            /**
             * Data for the upper half of the display is stored in the lower
             * bits of each byte.
             */
            /* Base address of current position of the pixel */
            _curPos = y * MATRIX_WIDTH * MAX_BIT + x;

            /**
             * The remaining three image planes are more normal-ish.
             * Data is stored in the high 6 bits so it can be quickly
             * copied to the DATAPORT register w/6 output lines.
             */
            while( bit < limit )
            {
                gBuff[_curPos] &= ~RGB3_MASK;
                if( r & bit ) gBuff[_curPos] |= R3_MASK;
                if( g & bit ) gBuff[_curPos] |= G3_MASK;
                if( b & bit ) gBuff[_curPos] |= B3_MASK;
                _curPos  += MATRIX_WIDTH;                /* Advance to next bit plane */
                bit <<= 1 ;
            }
        }
        else
        {
            /* Data for the lower half of the display is stored in the upper bits */
            _curPos = (y - MATRIX_SCANRATE) * MATRIX_WIDTH * MAX_BIT + x;

            while( bit < limit )
            {
                gBuff[_curPos] &= ~RGB4_MASK;
                if(r & bit) gBuff[_curPos] |= R4_MASK;
                if(g & bit) gBuff[_curPos] |= G4_MASK;
                if(b & bit) gBuff[_curPos] |= B4_MASK;
                _curPos  += MATRIX_WIDTH;             /* Advance to next bit plane */
                bit <<= 1 ;
            }
        }
    }
    else
#endif /* USE2BUS */

    /* Fill data to the first bus at default mode */
    if( y < MATRIX_SCANRATE)
    {
        /**
         * Data for the upper half of the display is stored in the lower
         * bits of each byte.
         */
        /* Base address of current position of the pixel */
        _curPos = y * MATRIX_WIDTH * MAX_BIT + x;

        /**
         * The remaining three image planes are more normal-ish.
         * Data is stored in the high 6 bits so it can be quickly
         * copied to the DATAPORT register w/6 output lines.
         */
        while( bit < limit )
        {
           gBuff[_curPos] &= (uint16_t) ~RGB1_MASK;                   /* 00000111b Mask out R,G,B in one op */
           if( r & bit ) gBuff[_curPos] |= R1_MASK;     /* Plane N R: bit 6 0000.0100.0000b     */
           if( g & bit ) gBuff[_curPos] |= G1_MASK;     /* Plane N G: bit 7 0000.1000.0000b     */
           if( b & bit ) gBuff[_curPos] |= B1_MASK;    /* Plane N B: bit 8 0001.0000.0000b     */
            _curPos  += MATRIX_WIDTH;                /* Advance to next bit plane */
            bit <<= 1 ;
        }
    }
   else
   {
       /* Data for the lower half of the display is stored in the upper bits */
       _curPos = (y - MATRIX_SCANRATE) * MATRIX_WIDTH * MAX_BIT + x;

       while( bit < limit )
       {
           gBuff[_curPos] &= (uint16_t)~RGB2_MASK;              /* 00111000b Mask out R,G,B in one op */
           if(r & bit) gBuff[_curPos] |= R2_MASK;    /* Plane N R: bit 11 1000.0000.0000b    */
           if(g & bit) gBuff[_curPos] |= G2_MASK;   /* Plane N G: bit 9  0010.0000.0000b    */
           if(b & bit) gBuff[_curPos] |= B2_MASK;   /* Plane N B: bit 10 0100.0000.0000b    */
           _curPos  += MATRIX_WIDTH;             /* Advance to next bit plane */
           bit <<= 1 ;
       }
   }
#else

    /**
     *
     *                  11  10  9   8   7   6   5   4   3   2   1   0
     *                  R3  R2  R1  R0  G3  G2  G1  G0  B3  B2  B1  B0
     *
     *                  G3  B3  R3  G2  B2  R2  G1  B1  R1  G0  B0  R0
     *      R3  11  ->          9
     *      R2  10  ->                      6
     *      R1  9   ->                                  3
     *      R0  8   ->                                              0
     *
     *      G3  7   ->  11
     *      G2  6   ->              8
     *      G1  5   ->                          5
     *      G0  4   ->                                      2
     *
     *      B3  3   ->      10
     *      B2  2   ->                  7
     *      B1  1   ->                              4
     *      B0  0   ->                                          1
     */

    gBuff[ y * MATRIX_WIDTH + x] = ((c >> 2u) & 0x200) | ((c >> 4u) &  0x40) | ((c >> 6u) &  0x8) | ((c >> 8u) & 0x1) | \
                                   ((c << 4u) & 0x800) | ((c << 2u) & 0x100) | ((c << 0u) & 0x20) | ((c >> 2u) & 0x4) | \
                                   ((c << 7u) & 0x400) | ((c << 5u) & 0x80)  | ((c << 3u) & 0x10) | ((c << 1u) & 0x2);
    // gBuff[ y * MATRIX_WIDTH + x] = 0xFFFF;
#endif
}

static inline uint16_t MATRIX_Color888( uint8_t r, uint8_t g, uint8_t b, bool gflag )
{
    if( gflag )
    { // Gamma-corrected color?
        r = pgm_read_byte(&gamma_table[r]); // Gamma correction table maps
        g = pgm_read_byte(&gamma_table[g]); // 8-bit input to 4-bit output
        b = pgm_read_byte(&gamma_table[b]);
        return  ((uint16_t)r << 12) | ((uint16_t)(r & 0x8) << 8) | // 4/4/4->5/6/5
                ((uint16_t)g <<  7) | ((uint16_t)(g & 0xC) << 3) |
                (          b <<  1) | (           b        >> 3);
    } // else linear (uncorrected) color
    return ((uint16_t)(r & 0xF8) << 8) | ((uint16_t)(g & 0xFC) << 3) | (b >> 3);
}

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/
/**
  * @brief  None.
  *
  * @param  None.
  * @retval None.
  */
StdReturnType MATRIX_Init( uint8_t bri )
{
    gBrightness = bri;

    return E_OK;
}

/**
  * @brief   Resfresh function for active display.
  * @details
  *             We have some plans for scan each bit matrix. it shall be listed below. Each case shall use the difference sources, timing..
  *             1. Decode pixel to the actual possition, IRQ only need move data to peripherals.
  *                 For example scan with 5bit per color per pixel
  *                 For each | w | instance, they store MATRIX_HEIGHT pixels.
  *                 |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |  w |
  *                 | b0 | b1 | b2 | b3 | b4 | b0 | b1 | b2 | b3 | b4 | b0 | b1 | b2 | b3 | b4 |
  *                 |---------- r0 ----------|---------- r1 ----------|---------- r2 ----------|
  *                 Total elements are MATRIX_WIDTH * MATRIX_HEIGHT * MAX_BIT. Actual only need to scan a half
  *                 part of one matrix.
  *             2. Only use the one data array gBuff[MATRIX_WIDTH * MATRIX_HEIGHT]. In this case, only prefer use the color code are RGB565, RGB555, RGB444...
  *                 Each interrupt event occured, we want to print out each bit possition like as below algorithm. This exemple shall be declare RGB565 encode
  *                 | R4 R3 R2 R1 R0 | G5 G4 G3 G2 G1 G0 | B4 B3 B2 B1 B0 |
  *                 u16TempDat = gBuff[ y * MATRIX_WIDTH + x ];
  *                 DAT_P->ODR = gBuff[ y * MATRIX_WIDTH + x ];
  * @param  None.
  * @retval None.
  */
void IRQ_ProcessMonitor( void )
{
    uint16_t u16Count = 0U;
    uint16_t t, duration;
    uint8_t u8Timeout = IRQ_TIMEDELAY;

    t = (MATRIX_WIDTH > 8) ? LOOPTIME : (LOOPTIME * 2);
    duration = ((t + CALLOVERHEAD * 2) << gBitPos) - CALLOVERHEAD;

    /* Load new division value */
    // TIM_DAT->PSC = gTimeCount[gBitPos];
    TIM_DAT->PSC = duration;
    /* Trigger EGR upto 1 in order re-load PSC value */
    TIM_DAT->EGR = 1U;
    /* Clear interrupt flag */
    TIM_DAT->SR = 0xFFFFFFFE;

    /* Latch data loaded during *prior* interrupt */
    LAT_P->BSRR = LAT_BIT_SET;
    /* Disable LED output during gRows/gBitPos switchover */
    TIM_OE->CCR3 = 0U;

    /* Release new data region */
    while( u16Count < MATRIX_WIDTH)
    {
        CLK_P->BSRR = CLK_BIT_RESET;
        DAT_P->ODR = ((gBuff[ (u16Count++) + gRows * MATRIX_WIDTH ] >> (gBitPos * 3)) & 0x7);
        CLK_P->BSRR = CLK_BIT_SET;
    }

    TIM_OE->CCR3 = gBrightness;
    LAT_P->BSRR = LAT_BIT_RESET;
    ROW_P->ODR = gRows;
    while( u8Timeout -- );

    if( ++gBitPos >= MAX_BIT )
    {
        gBitPos = 0U;
        if( ++gRows >= MATRIX_SCANRATE )
        {
            gRows = 0U;
            gCountBit = 0UL;
        }
    }
}

void MATRIX_UpdateScreen( void )
{
    (void) MATRIX_WIDTH;

#ifdef RECORD_LAST_FRAME
    gCurrFrame = !gCurrFrame;
    for( uint8_t lx = 0; lx < MATRIX_WIDTH; lx++ )
    {
        for( uint8_t ly = 0; ly < MATRIX_HEIGHT; ly++ )
        {
            if( gRecordFrame[lx/MATRIX_SCANRATE][ly][gCurrFrame]&gBitMask[lx%MATRIX_SCANRATE] )
            {
                if( 0 == (gRecordFrame[lx/MATRIX_SCANRATE][ly][1 - gCurrFrame]&gBitMask[lx%MATRIX_SCANRATE]) )
                {
                    MATRIX_DrawPixel(lx, ly, 0x0);
                }
                gRecordFrame[lx/MATRIX_SCANRATE][ly][gCurrFrame]&=(uint32_t)~gBitMask[lx%MATRIX_SCANRATE];
            }
        }
    }
#endif /* #ifdef RECORD_LAST_FRAME */
}
/**
  * @brief  None.
  *
  * @param  None.
  * @retval None.
  */
uint8_t MATRIX_getBrightness( void )
{
    return gBrightness;
}

/**
  * @brief  None.
  *
  * @param  None.
  * @retval None.
  */
StdReturnType MATRIX_setBrightness( uint8_t bri )
{
    gBrightness = bri;
    return E_OK;
}

inline void MATRIX_SwapBuffers( void )
{
    (void) 1U;
#ifdef USE_DOUBLE_BUFF
    gSwapFlag = true;
    while(gSwapFlag == true);
#endif
}

/**
  * @brief  None.
  *
  * @param  None.
  * @retval None.
  */
StdReturnType MATRIX_disImage( const uint8_t arr[], uint16_t nCols, uint16_t nRows)
{
    uint32_t p1;
    uint32_t c = 0;
    uint16_t row, col;
    uint8_t  r, g, b;

    for( row = 0; row < nRows; row++)
    {
        for( col = 0; col < nCols; col++)
        {
            p1 = row * nCols*3;
#if   defined(RGB888) || defined(RGB666)
            /**
             * In the case use RGB888 format, we didnt want to down quality
             * of the pixels.
             */
            r = arr[p1+col*3+2];
            g = arr[p1+col*3+1];
            b = arr[p1+col*3+0];

#elif defined(RGB565) || defined(RGB555) || defined(RGB444)
            r = pgm_read_byte(&gamma_table[(arr[p1+col*3+2] * 255) >> 8 ]);
            g = pgm_read_byte(&gamma_table[(arr[p1+col*3+1] * 255) >> 8 ]);
            b = pgm_read_byte(&gamma_table[(arr[p1+col*3+0] * 255) >> 8 ]);
#endif

#if   defined(RGB888)
            c = ((r << 16) & 0xFF0000) |
                ((g <<  8) & 0x00FF00) |
                ((b <<  0) & 0x0000FF);
#elif defined(RGB666)
            c = ((r << 10) & 0x3F000) |
                ((g <<  4) & 0x00FC0) |
                ((b >>  2) & 0x0003F);
#elif defined(RGB565)
            c = (r << 12) | ((r & 0x8) << 8) | // 4/4/4 -> 5/6/5
                (g <<  7) | ((g & 0xC) << 3) |
                (b <<  1) | ( b        >> 3);
#elif defined(RGB555)
            c = (r << 11) | ((r & 0x8) << 7) | // 4/4/4 -> 5/5/5
                (g <<  6) | ((g & 0x8) << 2) |
                (b <<  1) | ( b        >> 3);
#elif defined(RGB444)
            c = ((r << 8)&0xF00) |
                ((g << 4)&0x0F0) |
                ((b << 0)&0x00F);
#elif defined(RGB333)
#endif  /* defined(RGBxxx) */

            /* RGB565 rrrrrggggggbbbbb */
            // c = ((c>>8)&0xF800) | ((c>>5)&0x07E0) | ((c>>3)&0x1F);
            MATRIX_DrawPixel( col, row, c );
        }
    }
    MATRIX_SwapBuffers();
    return E_OK;
}

void MATRIX_WritePixel( uint16_t x, uint16_t y, uint16_t c )
{
    MATRIX_DrawPixel( x, y, c );
}

StdReturnType MATRIX_FillAllColorPannel( uint8_t cR, uint8_t cG, uint8_t cB )
{
    uint16_t y = 0, x = 0;
    uint32_t u32Color = 0UL;
#if defined(RGB666)
    /* Convert RGB888 to RGB666 */
    u32Color = ((cR << 10)&0x3F000) | ((cG<<4)&0xFB0) | ((cB>>2)&0x3F);
#elif defined(RGB565)
    /* Convert RGB888 to RGB565 */
    u32Color = ((cR << 8)&0xF800) | ((cG<<3)&0x07E0) | ((cB>>3)&0x1F);
#elif defined(RGB555)
    /* Convert RGB888 to RGB555 */
    u32Color = ((cR << 7)&0x3E00) | ((cG<<2)&0x03E0) | ((cB>>3)&0x1F);
#endif

    GPIOD->BSRR = (1<<29);
    for( y = 0U; y < MATRIX_HEIGHT; y++ )
    {
        for( x = 0U; x < MATRIX_WIDTH; x++ )
        {
            MATRIX_DrawPixel( x, y, u32Color );
        }
    }
    GPIOD->BSRR = (1<<13);
    MATRIX_SwapBuffers();
    return E_OK;
}

uint16_t ColorHSV( uint16_t x, uint16_t y, long hue, uint8_t sat, uint8_t val, char gflag)
{
  uint8_t  r, g, b, lo;
  uint16_t s1, v1;

  // Hue
  hue %= 1536;             // -1535 to +1535
  if(hue < 0) hue += 1536; //     0 to +1535
  lo = hue & 255;          // Low byte  = primary/secondary color mix
  switch(hue >> 8) {       // High byte = sextant of colorwheel
    case 0 : r = 255     ; g =  lo     ; b =   0     ; break; // R to Y
    case 1 : r = 255 - lo; g = 255     ; b =   0     ; break; // Y to G
    case 2 : r =   0     ; g = 255     ; b =  lo     ; break; // G to C
    case 3 : r =   0     ; g = 255 - lo; b = 255     ; break; // C to B
    case 4 : r =  lo     ; g =   0     ; b = 255     ; break; // B to M
    default: r = 255     ; g =   0     ; b = 255 - lo; break; // M to R
  }

  // Saturation: add 1 so range is 1 to 256, allowig a quick shift operation
  // on the result rather than a costly divide, while the type upgrade to int
  // avoids repeated type conversions in both directions.
  s1 = sat + 1;
  r  = 255 - (((255 - r) * s1) >> 8);
  g  = 255 - (((255 - g) * s1) >> 8);
  b  = 255 - (((255 - b) * s1) >> 8);

  // Value (brightness) & 16-bit color reduction: similar to above, add 1
  // to allow shifts, and upgrade to int makes other conversions implicit.
  v1 = val + 1;
  if(gflag) { // Gamma-corrected color?
    r = pgm_read_byte(&gamma_table[(r * v1) >> 8]); // Gamma correction table maps
    g = pgm_read_byte(&gamma_table[(g * v1) >> 8]); // 8-bit input to 4-bit output
    b = pgm_read_byte(&gamma_table[(b * v1) >> 8]);
  } else { // linear (uncorrected) color
    r = (r * v1) >> 12; // 4-bit results
    g = (g * v1) >> 12;
    b = (b * v1) >> 12;
  }
    // rgb = ((r & 0b11111000) << 8) | ((g & 0b11111100) << 3) | (b >> 3);
  return (r << 12) | ((r & 0x8) << 8) | // 4/4/4 -> 5/6/5
         (g <<  7) | ((g & 0xC) << 3) |
         (b <<  1) | ( b        >> 3);
}

void plasma( void )
{
    int           x1, x2, x3, x4, y1, y2, y3, y4, sx1, sx2, sx3, sx4;
    unsigned int x, y;
    long          value;
const float radius1 =16.3, radius2 =23.0, radius3 =40.8, radius4 =44.2,
            centerx1=16.1, centerx2=11.6, centerx3=23.4, centerx4= 4.1,
            centery1= 8.7, centery2= 6.5, centery3=14.0, centery4=-2.9;
double       angle1  = 0.0, angle2  = 0.0, angle3  = 0.0, angle4  = 0.0;
long        hueShift= 0;
    while (1)
    {
        HAL_Delay(1000);
        sx1 = (int)(cos(angle1) * radius1 + centerx1);
        sx2 = (int)(cos(angle2) * radius2 + centerx2);
        sx3 = (int)(cos(angle3) * radius3 + centerx3);
        sx4 = (int)(cos(angle4) * radius4 + centerx4);
        y1  = (int)(sin(angle1) * radius1 + centery1);
        y2  = (int)(sin(angle2) * radius2 + centery2);
        y3  = (int)(sin(angle3) * radius3 + centery3);
        y4  = (int)(sin(angle4) * radius4 + centery4);

        for(y=0; y<MATRIX_HEIGHT; y++)
        {
            x1 = sx1; x2 = sx2; x3 = sx3; x4 = sx4;
            for(x=0; x<MATRIX_WIDTH; x++)
            {
                value = hueShift
                    + (int8_t)pgm_read_byte(sinetab + (uint8_t)((x1 * x1 + y1 * y1) >> 5))
                    + (int8_t)pgm_read_byte(sinetab + (uint8_t)((x2 * x2 + y2 * y2) >> 5))
                    + (int8_t)pgm_read_byte(sinetab + (uint8_t)((x3 * x3 + y3 * y3) >> 6))
                    + (int8_t)pgm_read_byte(sinetab + (uint8_t)((x4 * x4 + y4 * y4) >> 6));
#ifdef RECORD_LAST_FRAME
                    if( (gRecordFrame[x/MATRIX_SCANRATE][y][1 - gCurrFrame]&gBitMask[x%MATRIX_SCANRATE]) )
#endif /* #ifdef RECORD_LAST_FRAME */
                    {
                        MATRIX_DrawPixel(x, y, ColorHSV(x/8, y/8, value * 5, 255, 150, 1) );
                    }
                    // matrix.drawPixel(x, y, ColorHSV(value * 3, 255, 255, 1));
                x1--; x2--; x3--; x4--;
            }
        y1--; y2--; y3--; y4--;
        }
        // MATRIX_SwapBuffers();

        angle1 += 0.03;
        angle2 -= 0.07;
        angle3 += 0.13;
        angle4 -= 0.15;
        hueShift += 0.02;
    }
}
/**
 *
 *  @brief    Draw a circle outline
 *
 *  @param    x0   Center-point x coordinate
 *  @param    y0   Center-point y coordinate
 *  @param    r   Radius of circle
 *  @param    color 16-bit 5-6-5 Color to draw with
 */
void MATRIX_DrawCircle( int16_t x0, int16_t y0, int16_t r, uint16_t u16Color )
{
    int16_t f = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x = 0;
    int16_t y = r;

    MATRIX_DrawPixel( x0  , y0+r, u16Color );
    MATRIX_DrawPixel( x0  , y0-r, u16Color );
    MATRIX_DrawPixel( x0+r, y0  , u16Color );
    MATRIX_DrawPixel( x0-r, y0  , u16Color );

    while (x<y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        x++;
        ddF_x += 2;
        f += ddF_x;

        MATRIX_DrawPixel( x0 + x, y0 + y, u16Color );
        MATRIX_DrawPixel( x0 - x, y0 + y, u16Color );
        MATRIX_DrawPixel( x0 + x, y0 - y, u16Color );
        MATRIX_DrawPixel( x0 - x, y0 - y, u16Color );
        MATRIX_DrawPixel( x0 + y, y0 + x, u16Color );
        MATRIX_DrawPixel( x0 - y, y0 + x, u16Color );
        MATRIX_DrawPixel( x0 + y, y0 - x, u16Color );
        MATRIX_DrawPixel( x0 - y, y0 - x, u16Color );
    }
}

/**
 *   @brief    Write a line.  Bresenham's algorithm - thx wikpedia
 *
 *   @param    x0  Start point x coordinate
 *   @param    y0  Start point y coordinate
 *   @param    x1  End point x coordinate
 *   @param    y1  End point y coordinate
 *   @param    color 16-bit 5-6-5 Color to draw with
 */
void MATRIX_WriteLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t u16Color )
{
    int16_t steep = abs(y1 - y0) > abs(x1 - x0);

    if (steep) {
        _swap_int16_t(x0, y0);
        _swap_int16_t(x1, y1);
    }

    if (x0 > x1) {
        _swap_int16_t(x0, x1);
        _swap_int16_t(y0, y1);
    }

    int16_t dx, dy;
    dx = x1 - x0;
    dy = abs(y1 - y0);

    int16_t err = dx / 2;
    int16_t ystep;

    if (y0 < y1) {
        ystep = 1;
    } else {
        ystep = -1;
    }

    for (; x0<=x1; x0++)
    {
        if( steep )
        {
#ifdef RECORD_LAST_FRAME
            if( !u16Color )
            {
                gRecordFrame[y0/MATRIX_SCANRATE][x0][gCurrFrame] |= gBitMask[y0%MATRIX_SCANRATE];
            }
            else
#endif /* #ifdef RECORD_LAST_FRAME */
            {
                MATRIX_DrawPixel(y0, x0, u16Color );
            }
        }
        else
        {
#ifdef RECORD_LAST_FRAME
            if( !u16Color )
            {
                gRecordFrame[x0/MATRIX_SCANRATE][y0][gCurrFrame] |= gBitMask[x0%MATRIX_SCANRATE];
            }
            else
#endif /* #ifdef RECORD_LAST_FRAME */
            {
                MATRIX_DrawPixel( x0, y0, u16Color );
            }
        }
        err -= dy;
        if (err < 0)
        {
            y0 += ystep;
            err += dx;
        }
    }
}

/**
 *   @brief    Draw a perfectly vertical line (this is often optimized in a subclass!)
 *
 *   @param    x   Top-most x coordinate
 *   @param    y   Top-most y coordinate
 *   @param    h   Height in pixels
 *   @param    color 16-bit 5-6-5 Color to fill with
 */
void MATRIX_DrawFastVLine( int16_t x, int16_t y, int16_t h, uint16_t u16Color )
{
    MATRIX_WriteLine(x, y, x, y+h-1, u16Color );
}

/**
 *   @brief    Draw a perfectly horizontal line (this is often optimized in a subclass!)
 *
 *   @param    x   Left-most x coordinate
 *   @param    y   Left-most y coordinate
 *   @param    w   Width in pixels
 *   @param    color 16-bit 5-6-5 Color to fill with
 */
void MATRIX_DrawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t u16Color )
{
    MATRIX_WriteLine( x, y, x+w-1, y, u16Color );
}

/*!
 *  @brief    Fill a rectangle completely with one color. Update in subclasses if desired!
 *
 *  @param    x   Top left corner x coordinate
 *  @param    y   Top left corner y coordinate
 *  @param    w   Width in pixels
 *  @param    h   Height in pixels
 *  @param    color 16-bit 5-6-5 Color to fill with
*/
void MATRIX_FillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t u16Color)
{
    for( int16_t i=x; i<x+w; i++)
    {
        MATRIX_DrawFastVLine(i, y, h, u16Color);
    }
}

/**
 *  @brief    Fill the screen completely with one color. Update in subclasses if desired!
 *
 *  @param    color 16-bit 5-6-5 Color to fill with
 */
void MATRIX_FillScreen(uint16_t u16Color )
{
    MATRIX_FillRect( 0, 0, MATRIX_WIDTH, MATRIX_HEIGHT, u16Color );
}

/**
 *  @brief    Draw a line
 *  @param    x0  Start point x coordinate
 *  @param    y0  Start point y coordinate
 *  @param    x1  End point x coordinate
 *  @param    y1  End point y coordinate
 *  @param    color 16-bit 5-6-5 Color to draw with
 */
void MATRIX_DrawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t u16Color )
{
    // Update in subclasses if desired!
    if(x0 == x1){
        if(y0 > y1) _swap_int16_t( y0, y1 );
        MATRIX_DrawFastVLine( x0, y0, y1 - y0 + 1, u16Color );
    } else if(y0 == y1){
        if( x0 > x1) _swap_int16_t( x0, x1 );
        MATRIX_DrawFastHLine( x0, y0, x1 - x0 + 1, u16Color );
    } else {
        MATRIX_WriteLine( x0, y0, x1, y1, u16Color );
    }
}

/**
 *  @brief    Quarter-circle drawer, used to do circles and roundrects
 *
 *  @param    x0   Center-point x coordinate
 *  @param    y0   Center-point y coordinate
 *  @param    r   Radius of circle
 *  @param    cornername  Mask bit #1 or bit #2 to indicate which quarters of the circle we're doing
 *  @param    color 16-bit 5-6-5 Color to draw with
 */
void MATRIX_DrawCircleHelper( int16_t x0, int16_t y0, int16_t r, uint8_t cornername, uint16_t u16Color )
{
    int16_t f     = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x     = 0;
    int16_t y     = r;

    while (x<y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f     += ddF_y;
        }
        x++;
        ddF_x += 2;
        f     += ddF_x;
        if (cornername & 0x4) {
            MATRIX_DrawPixel( x0 + x, y0 + y, u16Color );
            MATRIX_DrawPixel( x0 + y, y0 + x, u16Color );
        }
        if (cornername & 0x2) {
            MATRIX_DrawPixel( x0 + x, y0 - y, u16Color );
            MATRIX_DrawPixel( x0 + y, y0 - x, u16Color );
        }
        if (cornername & 0x8) {
            MATRIX_DrawPixel( x0 - y, y0 + x, u16Color );
            MATRIX_DrawPixel( x0 - x, y0 + y, u16Color );
        }
        if (cornername & 0x1) {
            MATRIX_DrawPixel( x0 - y, y0 - x, u16Color );
            MATRIX_DrawPixel( x0 - x, y0 - y, u16Color );
        }
    }
}

/**
 *  @brief    Draw a circle with filled color
 *
 *  @param    x0   Center-point x coordinate
 *  @param    y0   Center-point y coordinate
 *  @param    r   Radius of circle
 *  @param    color 16-bit 5-6-5 Color to fill with
 */
void MATRIX_FillCircle( int16_t x0, int16_t y0, int16_t r, uint16_t u16Color  )
{
    MATRIX_DrawFastVLine( x0, y0-r, 2*r+1, u16Color );
    MATRIX_FillCircleHelper( x0, y0, r, 3, 0, u16Color );
}

/**
 *  @brief  Quarter-circle drawer with fill, used for circles and roundrects
 *
 *  @param  x0       Center-point x coordinate
 *  @param  y0       Center-point y coordinate
 *  @param  r        Radius of circle
 *  @param  corners  Mask bits indicating which quarters we're doing
 *  @param  delta    Offset from center-point, used for round-rects
 *  @param  color    16-bit 5-6-5 Color to fill with
 */
void MATRIX_FillCircleHelper( int16_t x0, int16_t y0, int16_t r, uint8_t corners, int16_t delta, uint16_t u16Color  )
{
    int16_t f     = 1 - r;
    int16_t ddF_x = 1;
    int16_t ddF_y = -2 * r;
    int16_t x     = 0;
    int16_t y     = r;
    int16_t px    = x;
    int16_t py    = y;

    delta++; // Avoid some +1's in the loop

    while(x < y) {
        if (f >= 0) {
            y--;
            ddF_y += 2;
            f     += ddF_y;
        }
        x++;
        ddF_x += 2;
        f     += ddF_x;
        // These checks avoid double-drawing certain lines, important
        // for the SSD1306 library which has an INVERT drawing mode.
        if(x < (y + 1)) {
            if(corners & 1) MATRIX_DrawFastVLine( x0+x, y0-y, 2*y+delta, u16Color );
            if(corners & 2) MATRIX_DrawFastVLine( x0-x, y0-y, 2*y+delta, u16Color );
        }
        if(y != py) {
            if(corners & 1) MATRIX_DrawFastVLine( x0+py, y0-px, 2*px+delta, u16Color );
            if(corners & 2) MATRIX_DrawFastVLine( x0-py, y0-px, 2*px+delta, u16Color );
            py = y;
        }
        px = x;
    }
}

/**
 *  @brief   Draw a rectangle with no fill color
 *
 *  @param    x   Top left corner x coordinate
 *  @param    y   Top left corner y coordinate
 *  @param    w   Width in pixels
 *  @param    h   Height in pixels
 *  @param    color 16-bit 5-6-5 Color to draw with
 */
void MATRIX_DrawRect( int16_t x, int16_t y, int16_t w, int16_t h, uint16_t u16Color  )
{
    MATRIX_DrawFastHLine( x, y, w, u16Color );
    MATRIX_DrawFastHLine( x, y+h-1, w, u16Color );
    MATRIX_DrawFastVLine( x, y, h, u16Color );
    MATRIX_DrawFastVLine( x+w-1, y, h, u16Color );
}

/**
 *  @brief   Draw a rounded rectangle with no fill color
 *
 *  @param    x   Top left corner x coordinate
 *  @param    y   Top left corner y coordinate
 *  @param    w   Width in pixels
 *  @param    h   Height in pixels
 *  @param    r   Radius of corner rounding
 *  @param    color 16-bit 5-6-5 Color to draw with
 */
void MATRIX_DrawRoundRect( int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, uint16_t u16Color  )
{
    int16_t max_radius = ((w < h) ? w : h) / 2; // 1/2 minor axis
    if(r > max_radius) r = max_radius;
    // smarter version
    MATRIX_DrawFastHLine( x+r  , y    , w-2*r, u16Color ); // Top
    MATRIX_DrawFastHLine( x+r  , y+h-1, w-2*r, u16Color ); // Bottom
    MATRIX_DrawFastVLine( x    , y+r  , h-2*r, u16Color ); // Left
    MATRIX_DrawFastVLine( x+w-1, y+r  , h-2*r, u16Color ); // Right
    // draw four corners
    MATRIX_DrawCircleHelper( x+r    , y+r    , r, 1, u16Color );
    MATRIX_DrawCircleHelper( x+w-r-1, y+r    , r, 2, u16Color );
    MATRIX_DrawCircleHelper( x+w-r-1, y+h-r-1, r, 4, u16Color );
    MATRIX_DrawCircleHelper( x+r    , y+h-r-1, r, 8, u16Color );
}

/**
 *  @brief   Draw a rounded rectangle with fill color
 *
 *  @param    x   Top left corner x coordinate
 *  @param    y   Top left corner y coordinate
 *  @param    w   Width in pixels
 *  @param    h   Height in pixels
 *  @param    r   Radius of corner rounding
 *  @param    color 16-bit 5-6-5 Color to draw/fill with
 */
void MATRIX_FillRoundRect( int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, uint16_t u16Color  )
{
    int16_t max_radius = ((w < h) ? w : h) / 2; // 1/2 minor axis
    if(r > max_radius) r = max_radius;
    // smarter version
    MATRIX_FillRect( x+r, y, w-2*r, h, u16Color );
    // draw four corners
    MATRIX_FillCircleHelper( x+w-r-1, y+r, r, 1, h-2*r-1, u16Color );
    MATRIX_FillCircleHelper( x+r    , y+r, r, 2, h-2*r-1, u16Color );
}

/**
 *  @brief   Draw a triangle with no fill color
 *
 *  @param    x0  Vertex #0 x coordinate
 *  @param    y0  Vertex #0 y coordinate
 *  @param    x1  Vertex #1 x coordinate
 *  @param    y1  Vertex #1 y coordinate
 *  @param    x2  Vertex #2 x coordinate
 *  @param    y2  Vertex #2 y coordinate
 *  @param    color 16-bit 5-6-5 Color to draw with
 */
void MATRIX_DrawTriangle( int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t u16Color  )
{
    MATRIX_DrawLine( x0, y0, x1, y1, u16Color );
    MATRIX_DrawLine( x1, y1, x2, y2, u16Color );
    MATRIX_DrawLine( x2, y2, x0, y0, u16Color );
}

/**
 *   @brief     Draw a triangle with color-fill
 *
 *   @param    x0  Vertex #0 x coordinate
 *   @param    y0  Vertex #0 y coordinate
 *   @param    x1  Vertex #1 x coordinate
 *   @param    y1  Vertex #1 y coordinate
 *   @param    x2  Vertex #2 x coordinate
 *   @param    y2  Vertex #2 y coordinate
 *   @param    color 16-bit 5-6-5 Color to fill/draw with
 */
void MATRIX_FillTriangle( int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t u16Color  )
{

    int16_t a, b, y, last;

    // Sort coordinates by Y order (y2 >= y1 >= y0)
    if (y0 > y1) {
        _swap_int16_t(y0, y1); _swap_int16_t(x0, x1);
    }
    if (y1 > y2) {
        _swap_int16_t(y2, y1); _swap_int16_t(x2, x1);
    }
    if (y0 > y1) {
        _swap_int16_t(y0, y1); _swap_int16_t(x0, x1);
    }

    if(y0 == y2) { // Handle awkward all-on-same-line case as its own thing
        a = b = x0;
        if(x1 < a)      a = x1;
        else if(x1 > b) b = x1;
        if(x2 < a)      a = x2;
        else if(x2 > b) b = x2;
        MATRIX_DrawFastHLine( a, y0, b-a+1, u16Color );
        return;
    }

    int16_t
    dx01 = x1 - x0,
    dy01 = y1 - y0,
    dx02 = x2 - x0,
    dy02 = y2 - y0,
    dx12 = x2 - x1,
    dy12 = y2 - y1;
    int32_t
    sa   = 0,
    sb   = 0;

    // For upper part of triangle, find scanline crossings for segments
    // 0-1 and 0-2.  If y1=y2 (flat-bottomed triangle), the scanline y1
    // is included here (and second loop will be skipped, avoiding a /0
    // error there), otherwise scanline y1 is skipped here and handled
    // in the second loop...which also avoids a /0 error here if y0=y1
    // (flat-topped triangle).
    if(y1 == y2) last = y1;   // Include y1 scanline
    else         last = y1-1; // Skip it

    for(y=y0; y<=last; y++) {
        a   = x0 + sa / dy01;
        b   = x0 + sb / dy02;
        sa += dx01;
        sb += dx02;
        /* longhand:
        a = x0 + (x1 - x0) * (y - y0) / (y1 - y0);
        b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
        */
        if(a > b) _swap_int16_t(a,b);
        MATRIX_DrawFastHLine( a, y, b-a+1, u16Color );
    }

    // For lower part of triangle, find scanline crossings for segments
    // 0-2 and 1-2.  This loop is skipped if y1=y2.
    sa = (int32_t)dx12 * (y - y1);
    sb = (int32_t)dx02 * (y - y0);
    for(; y<=y2; y++) {
        a   = x1 + sa / dy12;
        b   = x0 + sb / dy02;
        sa += dx12;
        sb += dx02;
        /* longhand:
        a = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
        b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
        */
        if(a > b) _swap_int16_t(a,b);
        MATRIX_DrawFastHLine( a, y, b-a+1, u16Color );
    }
}

// TEXT- AND CHARACTER-HANDLING FUNCTIONS ----------------------------------

/**
 *  @brief   Draw a single character
 *
 *  @param    x   Bottom left corner x coordinate
 *  @param    y   Bottom left corner y coordinate
 *  @param    c   The 8-bit font-indexed character (likely ascii)
 *  @param    color 16-bit 5-6-5 Color to draw chraracter with
 *  @param    bg 16-bit 5-6-5 Color to fill background with (if same as color, no background)
 *  @param    size_x  Font magnification level in X-axis, 1 is 'original' size
 *  @param    size_y  Font magnification level in Y-axis, 1 is 'original' size
*/
void MATRIX_DrawChar( int16_t x, int16_t y, unsigned char c, uint8_t size_x, uint8_t size_y, MATRIX_FontTypes nFontType, uint16_t u16Color )
{
    if( FONT_DEFAULT == nFontType )
    { // 'Classic' built-in font
    // if(1) { // 'Classic' built-in font

        if((x >= MATRIX_WIDTH)            || // Clip right
           (y >= MATRIX_HEIGHT)           || // Clip bottom
           ((x + 6 * size_x - 1) < 0) || // Clip left
           ((y + 8 * size_y - 1) < 0))   // Clip top
            return;

        if(!gCp437 && (c >= 176)) c++; // Handle 'classic' charset behavior
        MATRIX_FillRect(x, y, 5*size_x, 8*size_y, 0x0);
        for(int8_t i=0; i<5; i++ ) { // Char bitmap = 5 columns
            uint8_t line = pgm_read_byte(&font[c * 5 + i]);
            for(int8_t j=0; j<8; j++, line >>= 1) {
                if(line & 1) {
                    if(size_x == 1 && size_y == 1)
                    {
#ifdef RECORD_LAST_FRAME
                        if( !u16Color )
                        {
                            gRecordFrame[(x+i)/MATRIX_SCANRATE][y+j][gCurrFrame] |= gBitMask[(x+i)%MATRIX_SCANRATE];
                        }
                        else
#endif /* #ifdef RECORD_LAST_FRAME */
                        {
                            MATRIX_DrawPixel(x+i, y+j, u16Color);
                        }
                    }
                    else
                    {
                        MATRIX_FillRect(x+i*size_x, y+j*size_y, size_x, size_y, u16Color);
                    }
                }
            }
        }
        // if(bg != color) { // If opaque, draw vertical line for last column
        //     if(size_x == 1 && size_y == 1) MATRIX_DrawFastVLine(x+5, y, 8, bg);
        //     else          MATRIX_FillRect(x+5*size_x, y, size_x, 8*size_y, bg);
        // }

    } else { // Custom font

        // Character is assumed previously filtered by write() to eliminate
        // newlines, returns, non-printable characters, etc.  Calling
        // drawChar() directly with 'bad' characters of font may cause mayhem!

        c -= (uint8_t)pgm_read_byte(&gfxFont->first);
        GFXglyph *glyph  = pgm_read_glyph_ptr(gfxFont, c);
        uint8_t  *bitmap = pgm_read_bitmap_ptr(gfxFont);

        uint16_t bo = pgm_read_word(&glyph->bitmapOffset);
        uint8_t  w  = pgm_read_byte(&glyph->width),
                 h  = pgm_read_byte(&glyph->height);
        int8_t   xo = pgm_read_byte(&glyph->xOffset),
                 yo = pgm_read_byte(&glyph->yOffset);
        uint8_t  xx, yy, bits = 0, bit = 0;
        int16_t  xo16 = 0, yo16 = 0;

        if(size_x > 1 || size_y > 1) {
            xo16 = xo;
            yo16 = yo;
        }

        // Todo: Add character clipping here

        // NOTE: THERE IS NO 'BACKGROUND' COLOR OPTION ON CUSTOM FONTS.
        // THIS IS ON PURPOSE AND BY DESIGN.  The background color feature
        // has typically been used with the 'classic' font to overwrite old
        // screen contents with new data.  This ONLY works because the
        // characters are a uniform size; it's not a sensible thing to do with
        // proportionally-spaced fonts with glyphs of varying sizes (and that
        // may overlap).  To replace previously-drawn text when using a custom
        // font, use the getTextBounds() function to determine the smallest
        // rectangle encompassing a string, erase the area with fillRect(),
        // then draw new text.  This WILL infortunately 'blink' the text, but
        // is unavoidable.  Drawing 'background' pixels will NOT fix this,
        // only creates a new set of problems.  Have an idea to work around
        // this (a canvas object type for MCUs that can afford the RAM and
        // displays supporting setAddrWindow() and pushColors()), but haven't
        // implemented this yet.
        // MATRIX_FillRect(x, y-h, w/2, h, 0x0);
        for(yy=0; yy<h; yy++) {
            for(xx=0; xx<w; xx++) {
                if(!(bit++ & 7)) {
                    bits = pgm_read_byte(&bitmap[bo++]);
                }
                if(bits & 0x80)
                {
                    if(size_x == 1 && size_y == 1)
                    {
#ifdef RECORD_LAST_FRAME
                        if( !u16Color )
                        {
                            gRecordFrame[(x+xo+xx)/MATRIX_SCANRATE][y+yo+yy][gCurrFrame] |= gBitMask[(x+xo+xx)%MATRIX_SCANRATE];
                        }
                        else
#endif /* #ifdef RECORD_LAST_FRAME */
                        {
                            MATRIX_DrawPixel(x+xo+xx, y+yo+yy, u16Color);
                        }
                    }
                    else
                    {
                        MATRIX_FillRect( x+(xo16+xx)*size_x, y+(yo16+yy)*size_y,
                          size_x, size_y, u16Color );
                    }
                }
                bits <<= 1;
            }
        }

    } // End classic vs custom font
}

/**
 *  @brief  Print one byte/character of data, used to support print()
 *
 *  @param  c  The 8-bit ascii character to write
 */
size_t MATRIX_Write( uint8_t c, MATRIX_FontTypes nFontType, uint16_t u16Color )
{
    if( FONT_DEFAULT == nFontType ) // 'Classic' built-in font
    {
        if(c == '\n') {                        // Newline?
            gCursorX  = 0;                     // Reset x to zero,
            gCursorY += gTextSizeY * 8;        // advance y one line
        } else if(c != '\r') {                 // Ignore carriage returns
            if(((gCursorX + gTextSizeX * 6) > MATRIX_WIDTH)) { // Off right?
                gCursorX  = 0;                 // Reset x to zero,
                gCursorY += gTextSizeY * 8;    // advance y one line
            }
            MATRIX_DrawChar(gCursorX, gCursorY, c, gTextSizeX, gTextSizeY, nFontType, u16Color );
            gCursorX += gTextSizeX * 6;          // Advance x one char
        }
    } else
    {
        if(c == '\n') {
            gCursorX  = 0;
            gCursorY += (int16_t)gTextSizeY *
                        (uint8_t)pgm_read_byte(&gfxFont->yAdvance);
        } else if(c != '\r') {
            uint8_t first = pgm_read_byte(&gfxFont->first);
            if((c >= first) && (c <= (uint8_t)pgm_read_byte(&gfxFont->last))) {
                GFXglyph *glyph  = pgm_read_glyph_ptr(gfxFont, c - first);
                uint8_t   w     = pgm_read_byte(&glyph->width),
                          h     = pgm_read_byte(&glyph->height);
                if((w > 0) && (h > 0)) { // Is there an associated bitmap?
                    int16_t xo = (int8_t)pgm_read_byte(&glyph->xOffset); // sic
                    if(((gCursorX + gTextSizeX * (xo + w/2)) > MATRIX_WIDTH))
                    {
                        gCursorX  = 0;
                        gCursorY += (int16_t)gTextSizeY * (uint8_t)pgm_read_byte(&gfxFont->yAdvance);
                        if( gCursorY > MATRIX_HEIGHT)
                        {
                            gCursorY = (int16_t)gTextSizeY * (uint8_t)pgm_read_byte(&gfxFont->yAdvance);
                        }
                    }
                    MATRIX_DrawChar(gCursorX, gCursorY, c, gTextSizeX, gTextSizeY, nFontType, u16Color );
                }
                gCursorX += (uint8_t)pgm_read_byte(&glyph->xAdvance) * (int16_t)gTextSizeX;
            }
        }
    }
    return 1;
}

/**
 *  @brief   Set text 'magnification' size. Each increase in s makes 1 pixel that much bigger.
 *
 * @param  s  Desired text size. 1 is default 6x8, 2 is 12x16, 3 is 18x24, etc
 */
void MATRIX_SetTextSize( uint8_t s )
{
    gTextSizeX = (s > 0) ? s : 1;
    gTextSizeY = (s > 0) ? s : 1;
}

/**
 *   @brief      Set rotation setting for display
 *
 *   @param  x   0 thru 3 corresponding to 4 cardinal rotations
 */
void MATRIX_SetRotation( uint8_t x )
{
    (void) x;
    // switch(x & 3) {
    //     case 0:
    //     case 2:
    //         _width  = WIDTH;
    //         _height = HEIGHT;
    //         break;
    //     case 1:
    //     case 3:
    //         _width  = HEIGHT;
    //         _height = WIDTH;
    //         break;
    // }
}

void MATRIX_Print( uint8_t *s, MATRIX_FontTypes nFontType, uint16_t u16Color )
{
    while (*s)
    {
        MATRIX_Write(*s++, nFontType, u16Color );
    }
}

void MATRIX_Printf( MATRIX_FontTypes nFontType, uint16_t u16Color, char *fmt, ... )
{
    va_list argp;
    va_start(argp, fmt);
    if( FONT_TOMTHUMB == nFontType)
    {
        gfxFont = &TomThumb;
    }
    else if( FONT_FREESERIF9PT7B == nFontType )
    {
        gfxFont = &FreeSerif9pt7b;
    }
    else if ( FONR_FREESERIFBOLDITALIC18PT7B == nFontType )
    {
        gfxFont = &FreeSerifBoldItalic18pt7b;
    }
    else if ( FONR_FREESANOBLIQUE9PT7B == nFontType )
    {
        gfxFont = &FreeSansOblique9pt7b;
    }
    MATRIX_Vprint( nFontType, u16Color, fmt, argp );
    va_end(argp);
}
/**
 *  @brief  Set text cursor location
 *
 *  @param  x    X coordinate in pixels
 *  @param  y    Y coordinate in pixels
 */
inline void MATRIX_SetCursor( int16_t x, int16_t y )
{
    gCursorX = x;
    gCursorY = y;
}

#if 0
/*!
    @brief   Set text 'magnification' size. Each increase in s makes 1 pixel that much bigger.
    @param  s  Desired text size. 1 is default 6x8, 2 is 12x16, 3 is 18x24, etc
*/
void Adafruit_GFX::setTextSize(uint8_t s) {
    setTextSize(s, s);
}

/*!
    @brief Set the font to display when print()ing, either custom or default
    @param  f  The GFXfont object, if NULL use built in 6x8 font
*/
void Adafruit_GFX::setFont(const GFXfont *f) {
    if(f) {            // Font struct pointer passed in?
        if(!gfxFont) { // And no current font struct?
            // Switching from classic to new font behavior.
            // Move cursor pos down 6 pixels so it's on baseline.
            gCursorY += 6;
        }
    } else if(gfxFont) { // NULL passed.  Current font struct defined?
        // Switching from new to classic font behavior.
        // Move cursor pos up 6 pixels so it's at top-left of char.
        gCursorY -= 6;
    }
    gfxFont = (GFXfont *)f;
}


/*!
    @brief    Helper to determine size of a character with current font/size.
       Broke this out as it's used by both the PROGMEM- and RAM-resident getTextBounds() functions.
    @param    c     The ascii character in question
    @param    x     Pointer to x location of character
    @param    y     Pointer to y location of character
    @param    minx  Minimum clipping value for X
    @param    miny  Minimum clipping value for Y
    @param    maxx  Maximum clipping value for X
    @param    maxy  Maximum clipping value for Y
*/
void Adafruit_GFX::charBounds(char c, int16_t *x, int16_t *y,
  int16_t *minx, int16_t *miny, int16_t *maxx, int16_t *maxy) {

    if(gfxFont) {

        if(c == '\n') { // Newline?
            *x  = 0;    // Reset x to zero, advance y by one line
            *y += textsize_y * (uint8_t)pgm_read_byte(&gfxFont->yAdvance);
        } else if(c != '\r') { // Not a carriage return; is normal char
            uint8_t first = pgm_read_byte(&gfxFont->first),
                    last  = pgm_read_byte(&gfxFont->last);
            if((c >= first) && (c <= last)) { // Char present in this font?
                GFXglyph *glyph = pgm_read_glyph_ptr(gfxFont, c - first);
                uint8_t gw = pgm_read_byte(&glyph->width),
                        gh = pgm_read_byte(&glyph->height),
                        xa = pgm_read_byte(&glyph->xAdvance);
                int8_t  xo = pgm_read_byte(&glyph->xOffset),
                        yo = pgm_read_byte(&glyph->yOffset);
                if(wrap && ((*x+(((int16_t)xo+gw)*textsize_x)) > _width)) {
                    *x  = 0; // Reset x to zero, advance y by one line
                    *y += textsize_y * (uint8_t)pgm_read_byte(&gfxFont->yAdvance);
                }
                int16_t tsx = (int16_t)textsize_x,
                        tsy = (int16_t)textsize_y,
                        x1 = *x + xo * tsx,
                        y1 = *y + yo * tsy,
                        x2 = x1 + gw * tsx - 1,
                        y2 = y1 + gh * tsy - 1;
                if(x1 < *minx) *minx = x1;
                if(y1 < *miny) *miny = y1;
                if(x2 > *maxx) *maxx = x2;
                if(y2 > *maxy) *maxy = y2;
                *x += xa * tsx;
            }
        }

    } else { // Default font

        if(c == '\n') {                     // Newline?
            *x  = 0;                        // Reset x to zero,
            *y += textsize_y * 8;           // advance y one line
            // min/max x/y unchaged -- that waits for next 'normal' character
        } else if(c != '\r') {  // Normal char; ignore carriage returns
            if(wrap && ((*x + textsize_x * 6) > _width)) { // Off right?
                *x  = 0;                    // Reset x to zero,
                *y += textsize_y * 8;       // advance y one line
            }
            int x2 = *x + textsize_x * 6 - 1, // Lower-right pixel of char
                y2 = *y + textsize_y * 8 - 1;
            if(x2 > *maxx) *maxx = x2;      // Track max x, y
            if(y2 > *maxy) *maxy = y2;
            if(*x < *minx) *minx = *x;      // Track min x, y
            if(*y < *miny) *miny = *y;
            *x += textsize_x * 6;             // Advance x one char
        }
    }
}

/*!
    @brief    Helper to determine size of a string with current font/size. Pass string and a cursor position, returns UL corner and W,H.
    @param    str     The ascii string to measure
    @param    x       The current cursor X
    @param    y       The current cursor Y
    @param    x1      The boundary X coordinate, set by function
    @param    y1      The boundary Y coordinate, set by function
    @param    w      The boundary width, set by function
    @param    h      The boundary height, set by function
*/
void Adafruit_GFX::getTextBounds(const char *str, int16_t x, int16_t y,
        int16_t *x1, int16_t *y1, uint16_t *w, uint16_t *h) {
    uint8_t c; // Current character

    *x1 = x;
    *y1 = y;
    *w  = *h = 0;

    int16_t minx = _width, miny = _height, maxx = -1, maxy = -1;

    while((c = *str++))
        charBounds(c, &x, &y, &minx, &miny, &maxx, &maxy);

    if(maxx >= minx) {
        *x1 = minx;
        *w  = maxx - minx + 1;
    }
    if(maxy >= miny) {
        *y1 = miny;
        *h  = maxy - miny + 1;
    }
}

/*!
    @brief    Helper to determine size of a string with current font/size. Pass string and a cursor position, returns UL corner and W,H.
    @param    str    The ascii string to measure (as an arduino String() class)
    @param    x      The current cursor X
    @param    y      The current cursor Y
    @param    x1     The boundary X coordinate, set by function
    @param    y1     The boundary Y coordinate, set by function
    @param    w      The boundary width, set by function
    @param    h      The boundary height, set by function
*/
void Adafruit_GFX::getTextBounds(const String &str, int16_t x, int16_t y,
        int16_t *x1, int16_t *y1, uint16_t *w, uint16_t *h) {
    if (str.length() != 0) {
        getTextBounds(const_cast<char*>(str.c_str()), x, y, x1, y1, w, h);
    }
}


/*!
    @brief    Helper to determine size of a PROGMEM string with current font/size. Pass string and a cursor position, returns UL corner and W,H.
    @param    str     The flash-memory ascii string to measure
    @param    x       The current cursor X
    @param    y       The current cursor Y
    @param    x1      The boundary X coordinate, set by function
    @param    y1      The boundary Y coordinate, set by function
    @param    w      The boundary width, set by function
    @param    h      The boundary height, set by function
*/
void Adafruit_GFX::getTextBounds(const __FlashStringHelper *str,
        int16_t x, int16_t y, int16_t *x1, int16_t *y1, uint16_t *w, uint16_t *h) {
    uint8_t *s = (uint8_t *)str, c;

    *x1 = x;
    *y1 = y;
    *w  = *h = 0;

    int16_t minx = _width, miny = _height, maxx = -1, maxy = -1;

    while((c = pgm_read_byte(s++)))
        charBounds(c, &x, &y, &minx, &miny, &maxx, &maxy);

    if(maxx >= minx) {
        *x1 = minx;
        *w  = maxx - minx + 1;
    }
    if(maxy >= miny) {
        *y1 = miny;
        *h  = maxy - miny + 1;
    }
}

/*!
    @brief      Invert the display (ideally using built-in hardware command)
    @param   i  True if you want to invert, false to make 'normal'
*/
void Adafruit_GFX::invertDisplay(boolean i) {
    // Do nothing, must be subclassed if supported by hardware
}

/***************************************************************************/

/*!
   @brief    Create a simple drawn button UI element
*/
Adafruit_GFX_Button::Adafruit_GFX_Button(void) {
  _gfx = 0;
}

/*!
   @brief    Initialize button with our desired color/size/settings
   @param    gfx     Pointer to our display so we can draw to it!
   @param    x       The X coordinate of the center of the button
   @param    y       The Y coordinate of the center of the button
   @param    w       Width of the buttton
   @param    h       Height of the buttton
   @param    outline  Color of the outline (16-bit 5-6-5 standard)
   @param    fill  Color of the button fill (16-bit 5-6-5 standard)
   @param    textcolor  Color of the button label (16-bit 5-6-5 standard)
   @param    label  Ascii string of the text inside the button
   @param    textsize The font magnification of the label text
*/
// Classic initButton() function: pass center & size
void Adafruit_GFX_Button::initButton(
 Adafruit_GFX *gfx, int16_t x, int16_t y, uint16_t w, uint16_t h,
 uint16_t outline, uint16_t fill, uint16_t textcolor,
 char *label, uint8_t textsize)
{
  // Tweak arguments and pass to the newer initButtonUL() function...
  initButtonUL(gfx, x - (w / 2), y - (h / 2), w, h, outline, fill,
    textcolor, label, textsize);
}

/*!
   @brief    Initialize button with our desired color/size/settings
   @param    gfx     Pointer to our display so we can draw to it!
   @param    x       The X coordinate of the center of the button
   @param    y       The Y coordinate of the center of the button
   @param    w       Width of the buttton
   @param    h       Height of the buttton
   @param    outline  Color of the outline (16-bit 5-6-5 standard)
   @param    fill  Color of the button fill (16-bit 5-6-5 standard)
   @param    textcolor  Color of the button label (16-bit 5-6-5 standard)
   @param    label  Ascii string of the text inside the button
   @param    textsize_x The font magnification in X-axis of the label text
   @param    textsize_y The font magnification in Y-axis of the label text
*/
// Classic initButton() function: pass center & size
void Adafruit_GFX_Button::initButton(
 Adafruit_GFX *gfx, int16_t x, int16_t y, uint16_t w, uint16_t h,
 uint16_t outline, uint16_t fill, uint16_t textcolor,
 char *label, uint8_t textsize_x, uint8_t textsize_y)
{
  // Tweak arguments and pass to the newer initButtonUL() function...
  initButtonUL(gfx, x - (w / 2), y - (h / 2), w, h, outline, fill,
    textcolor, label, textsize_x, textsize_y);
}

/*!
   @brief    Initialize button with our desired color/size/settings, with upper-left coordinates
   @param    gfx     Pointer to our display so we can draw to it!
   @param    x1       The X coordinate of the Upper-Left corner of the button
   @param    y1       The Y coordinate of the Upper-Left corner of the button
   @param    w       Width of the buttton
   @param    h       Height of the buttton
   @param    outline  Color of the outline (16-bit 5-6-5 standard)
   @param    fill  Color of the button fill (16-bit 5-6-5 standard)
   @param    textcolor  Color of the button label (16-bit 5-6-5 standard)
   @param    label  Ascii string of the text inside the button
   @param    textsize The font magnification of the label text
*/
void Adafruit_GFX_Button::initButtonUL(
 Adafruit_GFX *gfx, int16_t x1, int16_t y1, uint16_t w, uint16_t h,
 uint16_t outline, uint16_t fill, uint16_t textcolor,
 char *label, uint8_t textsize)
{
  initButtonUL(gfx, x1, y1, w, h, outline, fill, textcolor, label, textsize, textsize);
}

/*!
   @brief    Initialize button with our desired color/size/settings, with upper-left coordinates
   @param    gfx     Pointer to our display so we can draw to it!
   @param    x1       The X coordinate of the Upper-Left corner of the button
   @param    y1       The Y coordinate of the Upper-Left corner of the button
   @param    w       Width of the buttton
   @param    h       Height of the buttton
   @param    outline  Color of the outline (16-bit 5-6-5 standard)
   @param    fill  Color of the button fill (16-bit 5-6-5 standard)
   @param    textcolor  Color of the button label (16-bit 5-6-5 standard)
   @param    label  Ascii string of the text inside the button
   @param    textsize_x The font magnification in X-axis of the label text
   @param    textsize_y The font magnification in Y-axis of the label text
*/
void Adafruit_GFX_Button::initButtonUL(
 Adafruit_GFX *gfx, int16_t x1, int16_t y1, uint16_t w, uint16_t h,
 uint16_t outline, uint16_t fill, uint16_t textcolor,
 char *label, uint8_t textsize_x, uint8_t textsize_y)
{
  _x1           = x1;
  _y1           = y1;
  _w            = w;
  _h            = h;
  _outlinecolor = outline;
  _fillcolor    = fill;
  _textcolor    = textcolor;
  _textsize_x   = textsize_x;
  _textsize_y   = textsize_y;
  _gfx          = gfx;
  strncpy(_label, label, 9);
}

/*!
   @brief    Draw the button on the screen
   @param    inverted Whether to draw with fill/text swapped to indicate 'pressed'
*/
void Adafruit_GFX_Button::drawButton(boolean inverted) {
  uint16_t fill, outline, text;

  if(!inverted) {
    fill    = _fillcolor;
    outline = _outlinecolor;
    text    = _textcolor;
  } else {
    fill    = _textcolor;
    outline = _outlinecolor;
    text    = _fillcolor;
  }

  uint8_t r = min(_w, _h) / 4; // Corner radius
  _gfx->fillRoundRect(_x1, _y1, _w, _h, r, fill);
  _gfx->drawRoundRect(_x1, _y1, _w, _h, r, outline);

  _gfx->setCursor(_x1 + (_w/2) - (strlen(_label) * 3 * _textsize_x),
    _y1 + (_h/2) - (4 * _textsize_y));
  _gfx->setTextColor(text);
  _gfx->setTextSize(_textsize_x, _textsize_y);
  _gfx->print(_label);
}
// BITMAP / XBITMAP / GRAYSCALE / RGB BITMAP FUNCTIONS ---------------------
/**
 *  @brief      Draw a PROGMEM-resident 1-bit image at the specified (x,y) position, using the specified foreground color (unset bits are transparent).
 *
 *  @param    x   Top left corner x coordinate
 *  @param    y   Top left corner y coordinate
 *  @param    bitmap  byte array with monochrome bitmap
 *  @param    w   Width of bitmap in pixels
 *  @param    h   Height of bitmap in pixels
 *  @param    color 16-bit 5-6-5 Color to draw with
 */
void Adafruit_GFX::drawBitmap(int16_t x, int16_t y,
  const uint8_t bitmap[], int16_t w, int16_t h, uint16_t u16Color ) {

    int16_t byteWidth = (w + 7) / 8; // Bitmap scanline pad = whole byte
    uint8_t byte = 0;

    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++) {
            if(i & 7) byte <<= 1;
            else      byte   = pgm_read_byte(&bitmap[j * byteWidth + i / 8]);
            if(byte & 0x80) writePixel(x+i, y, color);
        }
    }
}


/*!
   @brief      Draw a PROGMEM-resident 1-bit image at the specified (x,y) position, using the specified foreground (for set bits) and background (unset bits) colors.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with monochrome bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
    @param    color 16-bit 5-6-5 Color to draw pixels with
    @param    bg 16-bit 5-6-5 Color to draw background with
*/
void Adafruit_GFX::drawBitmap(int16_t x, int16_t y,
  const uint8_t bitmap[], int16_t w, int16_t h,
  uint16_t u16Color , uint16_t bg) {

    int16_t byteWidth = (w + 7) / 8; // Bitmap scanline pad = whole byte
    uint8_t byte = 0;

    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            if(i & 7) byte <<= 1;
            else      byte   = pgm_read_byte(&bitmap[j * byteWidth + i / 8]);
            writePixel(x+i, y, (byte & 0x80) ? color : bg);
        }
    }
    endWrite();
}

/*!
   @brief      Draw a RAM-resident 1-bit image at the specified (x,y) position, using the specified foreground color (unset bits are transparent).
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with monochrome bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
    @param    color 16-bit 5-6-5 Color to draw with
*/
void Adafruit_GFX::drawBitmap(int16_t x, int16_t y,
  uint8_t *bitmap, int16_t w, int16_t h, uint16_t u16Color ) {

    int16_t byteWidth = (w + 7) / 8; // Bitmap scanline pad = whole byte
    uint8_t byte = 0;

    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            if(i & 7) byte <<= 1;
            else      byte   = bitmap[j * byteWidth + i / 8];
            if(byte & 0x80) writePixel(x+i, y, color);
        }
    }
    endWrite();
}

/*!
   @brief      Draw a RAM-resident 1-bit image at the specified (x,y) position, using the specified foreground (for set bits) and background (unset bits) colors.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with monochrome bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
    @param    color 16-bit 5-6-5 Color to draw pixels with
    @param    bg 16-bit 5-6-5 Color to draw background with
*/
void Adafruit_GFX::drawBitmap(int16_t x, int16_t y,
  uint8_t *bitmap, int16_t w, int16_t h, uint16_t u16Color , uint16_t bg) {

    int16_t byteWidth = (w + 7) / 8; // Bitmap scanline pad = whole byte
    uint8_t byte = 0;

    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            if(i & 7) byte <<= 1;
            else      byte   = bitmap[j * byteWidth + i / 8];
            writePixel(x+i, y, (byte & 0x80) ? color : bg);
        }
    }
    endWrite();
}

/*!
   @brief      Draw PROGMEM-resident XBitMap Files (*.xbm), exported from GIMP.
   Usage: Export from GIMP to *.xbm, rename *.xbm to *.c and open in editor.
   C Array can be directly used with this function.
   There is no RAM-resident version of this function; if generating bitmaps
   in RAM, use the format defined by drawBitmap() and call that instead.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with monochrome bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
    @param    color 16-bit 5-6-5 Color to draw pixels with
*/
void Adafruit_GFX::drawXBitmap(int16_t x, int16_t y,
  const uint8_t bitmap[], int16_t w, int16_t h, uint16_t u16Color ) {

    int16_t byteWidth = (w + 7) / 8; // Bitmap scanline pad = whole byte
    uint8_t byte = 0;

    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            if(i & 7) byte >>= 1;
            else      byte   = pgm_read_byte(&bitmap[j * byteWidth + i / 8]);
            // Nearly identical to drawBitmap(), only the bit order
            // is reversed here (left-to-right = LSB to MSB):
            if(byte & 0x01) writePixel(x+i, y, color);
        }
    }
    endWrite();
}


/*!
   @brief   Draw a PROGMEM-resident 8-bit image (grayscale) at the specified (x,y) pos.
   Specifically for 8-bit display devices such as IS31FL3731; no color reduction/expansion is performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with grayscale bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
void Adafruit_GFX::drawGrayscaleBitmap(int16_t x, int16_t y,
  const uint8_t bitmap[], int16_t w, int16_t h) {
    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            writePixel(x+i, y, (uint8_t)pgm_read_byte(&bitmap[j * w + i]));
        }
    }
    endWrite();
}

/*!
   @brief   Draw a RAM-resident 8-bit image (grayscale) at the specified (x,y) pos.
   Specifically for 8-bit display devices such as IS31FL3731; no color reduction/expansion is performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with grayscale bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
void Adafruit_GFX::drawGrayscaleBitmap(int16_t x, int16_t y,
  uint8_t *bitmap, int16_t w, int16_t h) {
    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            writePixel(x+i, y, bitmap[j * w + i]);
        }
    }
    endWrite();
}


/*!
   @brief   Draw a PROGMEM-resident 8-bit image (grayscale) with a 1-bit mask
   (set bits = opaque, unset bits = clear) at the specified (x,y) position.
   BOTH buffers (grayscale and mask) must be PROGMEM-resident.
   Specifically for 8-bit display devices such as IS31FL3731; no color reduction/expansion is performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with grayscale bitmap
    @param    mask  byte array with mask bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
void Adafruit_GFX::drawGrayscaleBitmap(int16_t x, int16_t y,
  const uint8_t bitmap[], const uint8_t mask[],
  int16_t w, int16_t h) {
    int16_t bw   = (w + 7) / 8; // Bitmask scanline pad = whole byte
    uint8_t byte = 0;
    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            if(i & 7) byte <<= 1;
            else      byte   = pgm_read_byte(&mask[j * bw + i / 8]);
            if(byte & 0x80) {
                writePixel(x+i, y, (uint8_t)pgm_read_byte(&bitmap[j * w + i]));
            }
        }
    }
    endWrite();
}

/*!
   @brief   Draw a RAM-resident 8-bit image (grayscale) with a 1-bit mask
   (set bits = opaque, unset bits = clear) at the specified (x,y) position.
   BOTH buffers (grayscale and mask) must be RAM-residentt, no mix-and-match
   Specifically for 8-bit display devices such as IS31FL3731; no color reduction/expansion is performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with grayscale bitmap
    @param    mask  byte array with mask bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
void Adafruit_GFX::drawGrayscaleBitmap(int16_t x, int16_t y,
  uint8_t *bitmap, uint8_t *mask, int16_t w, int16_t h) {
    int16_t bw   = (w + 7) / 8; // Bitmask scanline pad = whole byte
    uint8_t byte = 0;
    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            if(i & 7) byte <<= 1;
            else      byte   = mask[j * bw + i / 8];
            if(byte & 0x80) {
                writePixel(x+i, y, bitmap[j * w + i]);
            }
        }
    }
    endWrite();
}


/*!
   @brief   Draw a PROGMEM-resident 16-bit image (RGB 5/6/5) at the specified (x,y) position.
   For 16-bit display devices; no color reduction performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with 16-bit color bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
void Adafruit_GFX::drawRGBBitmap(int16_t x, int16_t y,
  const uint16_t bitmap[], int16_t w, int16_t h) {
    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            writePixel(x+i, y, pgm_read_word(&bitmap[j * w + i]));
        }
    }
    endWrite();
}

/*!
   @brief   Draw a RAM-resident 16-bit image (RGB 5/6/5) at the specified (x,y) position.
   For 16-bit display devices; no color reduction performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with 16-bit color bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
void Adafruit_GFX::drawRGBBitmap(int16_t x, int16_t y,
  uint16_t *bitmap, int16_t w, int16_t h) {
    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            writePixel(x+i, y, bitmap[j * w + i]);
        }
    }
    endWrite();
}


/*!
   @brief   Draw a PROGMEM-resident 16-bit image (RGB 5/6/5) with a 1-bit mask (set bits = opaque, unset bits = clear) at the specified (x,y) position. BOTH buffers (color and mask) must be PROGMEM-resident. For 16-bit display devices; no color reduction performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with 16-bit color bitmap
    @param    mask  byte array with monochrome mask bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
void Adafruit_GFX::drawRGBBitmap(int16_t x, int16_t y,
  const uint16_t bitmap[], const uint8_t mask[],
  int16_t w, int16_t h) {
    int16_t bw   = (w + 7) / 8; // Bitmask scanline pad = whole byte
    uint8_t byte = 0;
    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            if(i & 7) byte <<= 1;
            else      byte   = pgm_read_byte(&mask[j * bw + i / 8]);
            if(byte & 0x80) {
                writePixel(x+i, y, pgm_read_word(&bitmap[j * w + i]));
            }
        }
    }
    endWrite();
}

/*!
   @brief   Draw a RAM-resident 16-bit image (RGB 5/6/5) with a 1-bit mask (set bits = opaque, unset bits = clear) at the specified (x,y) position. BOTH buffers (color and mask) must be RAM-resident. For 16-bit display devices; no color reduction performed.
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    bitmap  byte array with 16-bit color bitmap
    @param    mask  byte array with monochrome mask bitmap
    @param    w   Width of bitmap in pixels
    @param    h   Height of bitmap in pixels
*/
void Adafruit_GFX::drawRGBBitmap(int16_t x, int16_t y,
  uint16_t *bitmap, uint8_t *mask, int16_t w, int16_t h) {
    int16_t bw   = (w + 7) / 8; // Bitmask scanline pad = whole byte
    uint8_t byte = 0;
    startWrite();
    for(int16_t j=0; j<h; j++, y++) {
        for(int16_t i=0; i<w; i++ ) {
            if(i & 7) byte <<= 1;
            else      byte   = mask[j * bw + i / 8];
            if(byte & 0x80) {
                writePixel(x+i, y, bitmap[j * w + i]);
            }
        }
    }
    endWrite();
}
#endif
/*================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */
