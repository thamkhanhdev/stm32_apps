#include "ir1838.h"
#include "flash.h"
#include "matrix.h"

static IR_FieldTypes nIRCurrField = IR_RESERVED_FIELD;
static uint32_t u32CurrData = 0UL;
static uint8_t u8CurrentKey = 0U;
static uint8_t u8CurrentBit = 0U;
char key=0;
/**
 * The current matrix key codes for the keyboard has 17 buttons
 *  A2  62  E2
 *  22  02  C2
 *  E0  A8  90
 *  68  98  B0
 *      18
 *  10  38  5A
 *      4A
 */
static uint8_t Key_IR[6];
uint16_t GET_KEY_IR(int key)
{
    return Key_IR[key];
}
void SET_KEY_IR(int key,int dat)
{
    Key_IR[key]=dat;
}
uint16_t GET_datakeyIR(char i)
{
    return Key_IR[(uint16_t) i];
}
void SET_datakeyIR(uint16_t i,uint16_t val)
{
    Key_IR[i]=val;
}
char GET_key(void)
{
    char k = key;
    key=0;
    return k;
}
void SET_key(char val)
{
    key=val;
}
uint32_t GET_IR_data(void)
{
    return u32CurrData;
}
uint8_t IR1838_GetCurrentKey(void)
{
    return u8CurrentKey;
}
void IR1838_SetNextKey(uint8_t u8NextKey)
{
    u8CurrentKey=u8NextKey;
}
void IR_Start(void)
{
    NVIC_EnableIRQ(LL_EXTI_LINE_6);
}
void IR_Stop(void)
{
    NVIC_DisableIRQ(LL_EXTI_LINE_6);
}

/* TIM_IR should be configured input capture mode with falling edge */
void IR1838_IRQHandler(void)
{
    uint16_t u16CapturedValue;

    u16CapturedValue = LL_TIM_IC_GetCaptureCH1( TIM_IR );
    TIM_IR->CNT = 0U;

    switch( nIRCurrField )
    {
        case IR_RESERVED_FIELD:
            nIRCurrField = IR_LEADING_PULSE_FIELD;
            break;
        case IR_LEADING_PULSE_FIELD:
            if( (12000 <= u16CapturedValue) && (14000 >= u16CapturedValue) )
            {
                nIRCurrField = IR_DAT_FIELD;
                u32CurrData = 0UL;
                u8CurrentBit = 0U;
            }
            else
            {
                nIRCurrField = IR_RESERVED_FIELD;
            }
            break;
        case IR_DAT_FIELD:
            u32CurrData <<= 1UL;
            u8CurrentBit++;
            if( ((2100 <= u16CapturedValue) && (2400 >= u16CapturedValue)) )
            {
                u32CurrData |= 1UL;
            }
            if( 32U == u8CurrentBit )
            {
                nIRCurrField = IR_RESERVED_FIELD;
                if( (((u32CurrData >> 8U) & 0xFF) == ((uint8_t)~((uint8_t)(u32CurrData & 0xFF)))) && \
                    (((u32CurrData >> 16U) & 0xFF) == ((uint8_t)~((uint8_t)((u32CurrData >> 24U) & 0xFF)))) )
                {
                    u8CurrentKey = ((u32CurrData >> 8U) & 0xFF);
                }
                else
                {
                    u8CurrentKey = 0U;
                }

                MATRIX_SetCursor( 30, 0 );
                MATRIX_Printf( FONT_DEFAULT, (uint16_t) u32CurrData, "0x%02X\n", u8CurrentKey);
            }
            break;
        default:
            nIRCurrField = IR_RESERVED_FIELD;
            break;
    }

    if( LL_TIM_IsActiveFlag_CC1OVR( TIM_IR ) )
    {
        LL_TIM_ClearFlag_CC1OVR( TIM_IR );
    }

    // if(nIRCurrField == IR_ADDR_FIELD)
    //     nIRCurrField = IR_ADDR_FIELD;
    // else if(nIRCurrField == IR_ADDR_FIELD)
    // {
    //     IR_Stop();//tam thoi cam ngat IR de xu li
    //     nIRCurrField = IR_ADDR_FIELD;
    //     MATRIX_Printf( FONT_DEFAULT, gColor++, "nIRCurrField = =2!\n");
    //     LL_TIM_DisableIT_UPDATE(TIM_IR);
    //     LL_TIM_DisableCounter(TIM_IR);
    //     //xu li du lieu tai day
    //     if(GET_CurrentKey() != 0) //neu dang o trong mode hoc lenh
    //     {
    //         uint16_t data;
    //         data=GET_IR_data();

    //         MATRIX_SetCursor(0, 55 );
    //         // MATRIX_Printf( FONT_DEFAULT, gColor++, "IR Attach!");
    //         MATRIX_Printf( FONT_DEFAULT, 0xFF00, "..%i ", data);
    //         //clear key IR
    //         //so sanh trung lap data
    //         if(data != 0 && data != Key_IR[0] && data != Key_IR[1] && data != Key_IR[2] && data != Key_IR[3] && data != Key_IR[4] && data != Key_IR[5] )
    //         {

    //             MATRIX_Printf( FONT_DEFAULT, gColor++, "DAT!\n");
    //             if(GET_u8CurrentKey() == 1)
    //             {
    //                 SET_u8CurrentKey(2);
    //                 Key_IR[0]=data;
    //                 MATRIX_SetCursor(0, 10 );
    //                 // MATRIX_Printf( FONT_DEFAULT, gColor++, "IR Attach!");
    //                 MATRIX_Printf( FONT_DEFAULT, 0xFF00, "1.%i ", data);
    //                 // P5_clear();
    //                 // P5_chonvitri(0,0);
    //                 // P5_sendString_wColor(S{71,105,165,109,32,180,207,0},31,0,0);
    //                 // P5_chonvitri(0,16);
    //                 // P5_sendString_wColor(S{115,163,110,103,0},31,0,0);
    //             }
    //             else if( GET_u8CurrentKey() == 2)
    //             {
    //                 SET_u8CurrentKey(3);
    //                 Key_IR[1]=data;
    //                 MATRIX_Printf( FONT_DEFAULT, 0xFF0, "2.%i ", data);
    //                 // P5_clear();
    //                 // P5_chonvitri(0,0);
    //                 // P5_sendString_wColor(S{72,201,99,32,110,214,116},31,31,0);
    //                 // P5_chonvitri(0,16);
    //                 // P5_sendString_wColor(S{109,101,110,117,0},31,31,0);
    //             }
    //             else  if(GET_u8CurrentKey() == 3)
    //             {
    //                 SET_u8CurrentKey(4);
    //                 Key_IR[2]=data;
    //                 MATRIX_Printf( FONT_DEFAULT, 0xFF, "3.%i ", data);
    //                 // P5_clear();
    //                 // P5_chonvitri(0,0);
    //                 // P5_sendString_wColor(S{72,201,99,32,110,214,116,0},31,31,31);
    //                 // P5_chonvitri(0,16);
    //                 // P5_sendString_wColor(S{116,114,163,105,0},31,0,31);
    //             }
    //             else  if(GET_u8CurrentKey() == 4)
    //             {
    //                 SET_u8CurrentKey(5);
    //                 Key_IR[3]=data;
    //                 MATRIX_Printf( FONT_DEFAULT, 0xF00F, "4.%i ", data);
    //                 // P5_clear();
    //                 // P5_chonvitri(0,0);
    //                 // P5_sendString_wColor(S{72,201,99,32,110,214,116,0},31,31,31);
    //                 // P5_chonvitri(0,16);
    //                 // P5_sendString_wColor(S{112,104,165,105,0},31,0,31);
    //             }
    //             else  if(GET_u8CurrentKey() == 5)
    //             {
    //                 SET_u8CurrentKey(6);
    //                 Key_IR[4]=data;
    //                 MATRIX_Printf( FONT_DEFAULT, 0xA0A0, "5.%i ", data);
    //                 // P5_clear();
    //                 // P5_chonvitri(0,0);
    //                 // P5_sendString_wColor(S{72,201,99,32,110,214,116,0},31,31,31);
    //                 // P5_chonvitri(0,16);
    //                 // P5_sendString_wColor(S{116,104,111,163,116,0},0,0,31);
    //             }
    //             else if(GET_u8CurrentKey() == 6)  //hoc lenh ket thuc
    //             {
    //                 Key_IR[5]=data;
    //                 // EEP_write(5,data);
    //                 SET_u8CurrentKey(0);
    //                 MATRIX_Printf( FONT_DEFAULT, 0xA0A0, "EXIT.. ");
    //             }
    //         }
    //     }
    //     else
    //     {
    //         uint16_t data;
    //         MATRIX_Printf( FONT_DEFAULT, 0xFF00, "hsh");
    //         data=GET_IR_data();
    //         if(data == Key_IR[0])SET_key(1);
    //         else if(data == Key_IR[1])SET_key(2);
    //         else if(data == Key_IR[2])SET_key(3);
    //         else if(data == Key_IR[3])SET_key(4);
    //         else if(data == Key_IR[4])SET_key(5);
    //         else if(data == Key_IR[5])SET_key(6);
    //     }
    //     IR_Start();
    // }
}