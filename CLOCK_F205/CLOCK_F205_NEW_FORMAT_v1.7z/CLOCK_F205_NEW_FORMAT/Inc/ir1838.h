/*==================================================================================================
*   @file       IR1838.h
*   @author     Khanh Tham Duy
*   @contact    thamkhanhdev@gmail.com
*   @version    1.0.0
*
*   @brief      Reserved - API header.
*   @details    Contains declaration of the IR1838 communication.
*
*   @addtogroup BUILD_ENV_COMPONENT
*   @{
*/
/*==================================================================================================
*   Project              : Reserved.
*   Platform             : Reserved.
*
*   SW Version           : 1.0.0
*   Build Version        : Reserved
*
*   Copyright 2020, Inc.
*   All Rights Reserved.
==================================================================================================*/
/**
 * Note: Reserved.
 */
#ifndef IR1838_H
#define IR1838_H

#ifdef __cplusplus
extern "C"{
#endif


/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "main.h"
#include "Std_Types.h"

/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/
#define saiso 300
#define IR_PIN GPIO_PIN_6
#define TIM_IR  TIM3
/*==================================================================================================
*                                             ENUMS
==================================================================================================*/
typedef enum
{
    IR_LEADING_PULSE_FIELD,
    IR_DAT_FIELD,
    IR_RESERVED_FIELD
} IR_FieldTypes;

/*==================================================================================================
*                                STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/


/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/


/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/
//------------------------END-----------------------------//

void IR_Start(void);
void IR_Stop(void);
void IR_ngatT(void);
void IR1838_IRQHandler(void);
uint8_t IR1838_GetCurrentKey(void);
void IR1838_SetNextKey(uint8_t u8NextKey);
char GET_key(void);
void SET_key(char val);
uint32_t GET_IR_data(void);
uint16_t GET_KEY_IR(int key);
void SET_KEY_IR(int key,int dat);

#ifdef __cplusplus
}
#endif

#endif /* IR1838_H */

/** @} */
