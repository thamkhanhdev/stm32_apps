#include "stm32f2xx.h"
#include "Std_Types.h"
#include "stdint.h"
#include "string.h"


//#define DATA_START_ADDRESS 		 	((uint32_t)0x0801EC00)	//Page 123
#define DATA_START_ADDRESS 		 	((uint32_t)0x0801FC00)	//Page 127

void FLASH_Lock(void);
StdReturnType FLASH_Unlock(void);
StdReturnType FLASH_Erase(uint32_t u32Address);
StdReturnType FLASH_Write(uint16_t u16Address, uint16_t u16Data);
uint16_t FLASH_Read(uint16_t u16Address);

//so do bo nho EEPROM
#define ADD_BUTTON_TANG_DO_SANG_EEP   0
#define ADD_BUTTON_GIAM_DO_SANG_EEP   1
#define ADD_BUTTON_MENU_EEP           2
#define ADD_BUTTON_UP_EEP             3
#define ADD_BUTTON_DOWN_EEP           4
#define ADD_BUTTON_THOAT_EEP          5
#define ADD_dosang                    42


