/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"
#include "libjpeg.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "matrix.h"
#include "ir1838.h"
#include "flash.h"
#include "string.h"
#include "stdio.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* I2C Slave Address  */
#define DS3231_ADDRESS  0x68<<1

/* S3231 Register Addresses */
#define DS3231_REG_TIMEDATE   0x00
#define DS3231_REG_ALARMONE   0x07
#define DS3231_REG_ALARMTWO   0x0B

#define DS3231_REG_CONTROL    0x0E
#define DS3231_REG_STATUS     0x0F
#define DS3231_REG_AGING      0x10

#define DS3231_REG_TEMP       0x11

/* S3231 Register Data Size if not just 1 */
#define DS3231_REG_TIMEDATE_SIZE  7
#define DS3231_REG_ALARMONE_SIZE  4
#define DS3231_REG_ALARMTWO_SIZE  3

#define DS3231_REG_TEMP_SIZE  2

/* DS3231 Control Register Bits */
#define DS3231_A1IE   1<<0
#define DS3231_A2IE   1<<1
#define DS3231_INTCN  1<<2
#define DS3231_RS1    1<<3
#define DS3231_RS2    1<<4
#define DS3231_CONV   1<<5
#define DS3231_BBSQW  1<<6
#define DS3231_EOSC   1<<7
#define DS3231_AIEMASK    (DS3231_A1IE | DS3231_A2IE)
#define DS3231_RSMASK     (DS3231_RS1 | DS3231_RS2)

/* DS3231 Status Register Bits */
#define DS3231_A1F        1<<0
#define DS3231_A2F        1<<1
#define DS3231_BSY        1<<2
#define DS3231_EN32KHZ    1<<3
#define DS3231_OSF        1<<7
#define DS3231_AIFMASK    (DS3231_A1F | DS3231_A2F)

/* seconds accuracy */
enum DS3231AlarmOneControl
{
   /* bit order:  A1M4  DY/DT  A1M3  A1M2  A1M1 */
    DS3231AlarmOneControl_HoursMinutesSecondsDayOfMonthMatch = 0x00,
    DS3231AlarmOneControl_OncePerSecond = 0x17,
    DS3231AlarmOneControl_SecondsMatch = 0x16,
    DS3231AlarmOneControl_MinutesSecondsMatch = 0x14,
    DS3231AlarmOneControl_HoursMinutesSecondsMatch = 0x10,
    DS3231AlarmOneControl_HoursMinutesSecondsDayOfWeekMatch = 0x08,
};
typedef enum
{
    MODE_NORMAL,
    MODE_SETUPTIME,
    MODE_RESERVED,
} CLOCK_Modes;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c2;

SD_HandleTypeDef hsd;

/* USER CODE BEGIN PV */
uint8_t second,minute,hour,day,date,month,year;
uint8_t u8LastMin=255U;
static volatile uint8_t gUpdateTimeFlag = 1U;
static int8_t gH_X = 0U, gH_Y = 0U, gM_X = 0, gM_Y = 0U, gS_X = 0U, gS_Y = 0U;
static uint8_t gOldHour = 25U, gOldMin = 60U, gOldSec = 60U, gOldDate = 99U, gOldDay = 99U, gOldMon = 99U, gOldYear = 99U;
static uint8_t u8IsFirstDraw = 1U;
MATRIX_MonitorTypes gCurrentMonitor = MONITOR_DISPLAY_ANALOG_CLOCK0;
uint8_t receive_data[7],send_data[7];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C2_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM5_Init(void);
static void MX_TIM3_Init(void);
static void MX_SDIO_SD_Init(void);
/* USER CODE BEGIN PFP */
uint8_t BCD2DEC(uint8_t data);
uint8_t DEC2BCD(uint8_t data);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static inline void CLOCK_InitData()
{
    for( uint8_t u8KeyPos = IR_KEY_RESERVED; u8KeyPos < IR_TOTAL_KEY; u8KeyPos++ )
    {
        IR1838_SetKeysCode( (IR_KeysLists) u8KeyPos, (uint8_t) FLASH_Read(u8KeyPos));
        // MATRIX_Printf( FONT_DEFAULT, 1U, u8KeyPos * 13, 0, 0xF81F, "%02X ", IR1838_GetKeysCode(u8KeyPos) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, u8KeyPos * 13, 0, 0xF81F, "%02X ", FLASH_Read(u8KeyPos) );
    }
}

static inline void CLOCK_ResetDefaultState(void)
{
    gOldSec = gOldMin = gOldHour = gOldDate = gOldDay = gOldMon = gOldYear = 99U;
    u8IsFirstDraw = 1U;
}

static inline void CLOCK_UpdateKeyCode( void )
{
    IR_KeysLists nCurKey = IR_KEY_RESERVED;
    uint32_t u32PointerTick = 0U;
    uint32_t u32StrTick = 0U;
    uint8_t u8Logic = 0;
    uint8_t u8xCurPos = 0U;
    uint8_t u8yCurPos = 0U;
    // uint8_t l_u8CurrentBri = MATRIX_getBrightness();

    /* Avoid the warnings when it doesn't have any coding lines below */
    (void) 1U;

    /* Check whether the button for updating key code is turned on */
    /* Note: This pin shall active at low level */
    if( !(LL_GPIO_ReadInputPort( UPD_KEY_GPIO_Port ) & UPD_KEY_Pin) )
    {
        LL_mDelay(20);
        while( !(LL_GPIO_ReadInputPort( UPD_KEY_GPIO_Port ) & UPD_KEY_Pin) );
        gCurrentMonitor = MONITOR_SET_KEY;
        MATRIX_TransitionEffect( TRANS_LEFT, EFFECT_FADE_OUT );

        MATRIX_DrawRect( 0U, 0U, 128U,  64U, 0xEF0U );
        MATRIX_DrawFastHLine( 1U, 20U, 126U, 0xEF0U );
        MATRIX_DrawFastVLine( 20U, 1U,  19U, 0xEF0U );
        MATRIX_Printf( FONT_FREESERIF9PT7B, 1U, 21U, 14U, 0xF81F, "Update Keys" );

        /* Draw Menu button */
        MATRIX_FillCircle( 15U, 31U, 8U, 0xF800U );
        MATRIX_DrawRect( 11U, 26U, 9U, 2U, 0xFFFFU );
        MATRIX_DrawRect( 11U, 30U, 9U, 2U, 0xFFFFU );
        MATRIX_DrawRect( 11U, 34U, 9U, 2U, 0xFFFFU );

        /* Draw Exit button */
        MATRIX_FillCircle( 15U, 52U, 8U, 0xF800U );
        MATRIX_DrawLine( 11U, 48U, 19U, 56U, 0xFFFFU);
        MATRIX_DrawLine( 11U, 49U, 18U, 56U, 0xFFFFU);
        MATRIX_DrawLine( 10U, 49U, 18U, 57U, 0xFFFFU);
        MATRIX_DrawLine( 11U, 56U, 19U, 48U, 0xFFFFU);
        MATRIX_DrawLine( 10U, 56U, 19U, 47U, 0xFFFFU);
        MATRIX_DrawLine( 11U, 57U, 20U, 48U, 0xFFFFU);

        /* Draw up button */
        MATRIX_FillCircle( 60U, 32U, 8U, 0x33U );
        MATRIX_FillTriangle( 55U, 34U, 65U, 34U, 60U, 26U, 0xFFFFU );

        /* Draw down button */
        MATRIX_FillCircle( 60U, 52U, 8U, 0x33U );
        MATRIX_FillTriangle( 55U, 50U, 65U, 50U, 60U, 58U, 0xFFFFU );

        /* Draw left button */
        MATRIX_FillCircle( 45U, 42U, 8U, 0x33U );
        MATRIX_FillTriangle( 47U, 47U, 47U, 37U, 39U, 42U, 0xFFFFU );

        /* Draw right button */
        MATRIX_FillCircle( 75U, 42U, 8U, 0x33U );
        MATRIX_FillTriangle( 73U, 47U, 73U, 37U, 81U, 42U, 0xFFFFU );

        /* Draw selected button */
        MATRIX_FillCircle( 105U, 32U, 8U, 0xF800 );
        MATRIX_DrawRoundRect( 100U, 29U, 6U, 7U, 6U, 0xFFFFU );
        MATRIX_DrawFastVLine( 107U, 29U, 7U, 0xFFFFU );

        MATRIX_DrawLine( 107U, 32U, 110U, 29U, 0xFFFFU );
        MATRIX_DrawLine( 107U, 32U, 110U, 35U, 0xFFFFU );

        /* Draw Reserved button */
        MATRIX_FillCircle( 105U, 52U, 8U, 0xF800 );

        // for( uint8_t i = 0; i <= l_u8CurrentBri; i++)
        // {
        //     MATRIX_setBrightness(i);
        //     LL_mDelay(80);
        // }

        u32PointerTick = HAL_GetTick();
        u32StrTick = HAL_GetTick();
        IR1838_EnterSetupMode();
        while( IR_NORMAL_MODE != IR1838_GetCurrentMode() )
        {
            nCurKey = IR1838_GetCurrentKey();
            switch( nCurKey )
            {
                case IR_KEY_MENU:
                    u8xCurPos = 25U;
                    u8yCurPos = 31U;
                    break;
                case IR_KEY_EXIT:
                    u8xCurPos = 25U;
                    u8yCurPos = 52U;
                    break;
                case IR_KEY_UP:
                    u8xCurPos = 70U;
                    u8yCurPos = 31U;
                    break;
                case IR_KEY_DOWN:
                    u8xCurPos = 70U;
                    u8yCurPos = 53U;
                    break;
                case IR_KEY_LEFT:
                    u8xCurPos = 55U;
                    u8yCurPos = 42U;
                    break;
                case IR_KEY_RIGHT:
                    u8xCurPos = 85U;
                    u8yCurPos = 42U;
                    break;
                case IR_KEY_OK:
                    u8xCurPos = 115U;
                    u8yCurPos = 32U;
                    break;
                case IR_KEY_DONE:
                    IR1838_ExitSetupMode();
                    break;
                default:
                    break;
            }
            if( (150U < HAL_GetTick() - u32PointerTick) )
            {
                u32PointerTick = HAL_GetTick();
                u8Logic = !u8Logic;
                MATRIX_FillRect( u8xCurPos + 1U, u8yCurPos - 1U, 6U, 3U, (u8Logic?0:0x5C0U) );
                MATRIX_DrawLine( u8xCurPos, u8yCurPos, u8xCurPos + 2U, u8yCurPos - 2U, (u8Logic?0:0x7F0U));
                MATRIX_DrawLine( u8xCurPos, u8yCurPos, u8xCurPos + 2U, u8yCurPos + 2U, (u8Logic?0:0x7F0U));
            }
            if( 200U < HAL_GetTick() - u32StrTick )
            {
                u32StrTick = HAL_GetTick();
                MATRIX_FlutterLeftRight( 22U, 2U, 104U, 17U );
            }
        }
        MATRIX_FillRect(22U, 2U, 104U, 17U, 0x0U );
        MATRIX_Printf( FONT_FREESERIF9PT7B, 1U, 21U, 14U, 0xF81F, "Successful!" );

        for( uint8_t u8KeyPos = 1; u8KeyPos < 9; u8KeyPos++ )
        {
            FLASH_Write(u8KeyPos, IR1838_GetKeysCode(u8KeyPos));
        }

        LL_mDelay(1000);
        MATRIX_TransitionEffect( TRANS_LEFT, EFFECT_FADE_OUT );
        CLOCK_ResetDefaultState();

        gCurrentMonitor = MONITOR_DISPLAY_ANALOG_CLOCK0;
    }
}


#define CLOCK_CENTER_X 31U
#define CLOCK_CENTER_Y 31U
#define CLOCK_RADIOUS  31U
#define CLOCK_LENGHT_HOUR   10
#define CLOCK_LENGHT_MIN    15
#define CLOCK_LENGHT_SEC    20

#define CLOCK_DIGITAL_HM_X    67U
#define CLOCK_DIGITAL_HM_Y    25U
#define CLOCK_DIGITAL_DATE_X    67U
#define CLOCK_DIGITAL_DATE_Y    50U

static inline void MATRIX_AnalogClockMode0(void)
{
    int8_t l_HX, l_HY, l_MX, l_MY, l_SX, l_SY;
    if( gUpdateTimeFlag )
    {
        gUpdateTimeFlag = 0U;

        /* Clear old graphic */
        MATRIX_DrawLine( CLOCK_CENTER_X, CLOCK_CENTER_Y, CLOCK_CENTER_X + gM_X, CLOCK_CENTER_Y + gM_Y, 0x0U );
        MATRIX_DrawLine( CLOCK_CENTER_X, CLOCK_CENTER_Y, CLOCK_CENTER_X + gH_X, CLOCK_CENTER_Y + gH_Y, 0x0U );
        MATRIX_DrawLine( CLOCK_CENTER_X, CLOCK_CENTER_Y, CLOCK_CENTER_X + gS_X, CLOCK_CENTER_Y + gS_Y, 0x0U );

        if( u8IsFirstDraw )
        {
            u8IsFirstDraw = 0U;
            /* Draw new basic graphic */
            MATRIX_FillCircle( CLOCK_CENTER_X, CLOCK_CENTER_Y, CLOCK_RADIOUS, 0xFFFFU );
            MATRIX_FillCircle( CLOCK_CENTER_X, CLOCK_CENTER_Y, CLOCK_RADIOUS - 2U, 0x0U );
#if 0
            MATRIX_Printf( FONT_TOMTHUMB, 1U, 28U,  7U, 0xFF,  "12");
            MATRIX_Printf( FONT_TOMTHUMB, 1U,  2U, 34U, 0xFF,  "9");
            MATRIX_Printf( FONT_TOMTHUMB, 1U, 30U, 61U, 0xFF,  "6");
            MATRIX_Printf( FONT_TOMTHUMB, 1U, 58U, 34U, 0xFF,  "3");
#else
            MATRIX_Printf( FONT_DEFAULT, 1U, 25U,  3U, 0xF81FU,  "12");
            MATRIX_Printf( FONT_DEFAULT, 1U,  3U, 28U, 0xF81FU,  "9");
            MATRIX_Printf( FONT_DEFAULT, 1U, 29U, 53U, 0xF81FU,  "6");
            MATRIX_Printf( FONT_DEFAULT, 1U, 55U, 28U, 0xF81FU,  "3");

            MATRIX_Printf( FONT_ORG_01,  1U, 44U, 12U, 0xFFFFU,  "1");
            MATRIX_Printf( FONT_ORG_01,  1U, 50U, 21U, 0xFFFFU,  "2");

            MATRIX_Printf( FONT_ORG_01,  1U, 51U, 45U, 0xFFFFU,  "4");
            MATRIX_Printf( FONT_ORG_01,  1U, 42U, 54U, 0xFFFFU,  "5");

            MATRIX_Printf( FONT_ORG_01,  1U, 16U, 54U, 0xFFFFU,  "7");
            MATRIX_Printf( FONT_ORG_01,  1U,  7U, 45U, 0xFFFFU,  "8");

            MATRIX_Printf( FONT_ORG_01,  1U,  7U, 21U, 0xFFFFU,  "10");
            MATRIX_Printf( FONT_ORG_01,  1U, 16U, 12U, 0xFFFFU,  "11");
#endif
        }

        gH_X = l_HX = CLOCK_LENGHT_HOUR * sin( (hour + minute/60.0) / 6.0 * _PI );
        gH_Y = l_HY = -CLOCK_LENGHT_HOUR * cos( (hour + minute/60.0) / 6.0 * _PI );
        gM_X = l_MX = CLOCK_LENGHT_MIN * sin( minute / 30.0 * _PI );
        gM_Y = l_MY = -CLOCK_LENGHT_MIN * cos( minute / 30.0 * _PI );
        gS_X = l_SX = CLOCK_LENGHT_SEC * sin( second / 30.0 * _PI );
        gS_Y = l_SY = -CLOCK_LENGHT_SEC * cos( second / 30.0 * _PI );

        MATRIX_DrawLine( CLOCK_CENTER_X, CLOCK_CENTER_Y, CLOCK_CENTER_X + l_MX, CLOCK_CENTER_Y + l_MY, 0xF800 );
        MATRIX_DrawLine( CLOCK_CENTER_X, CLOCK_CENTER_Y, CLOCK_CENTER_X + l_HX, CLOCK_CENTER_Y + l_HY, 0x7E0 );
        MATRIX_DrawLine( CLOCK_CENTER_X, CLOCK_CENTER_Y, CLOCK_CENTER_X + l_SX, CLOCK_CENTER_Y + l_SY, 0x1F );
        MATRIX_FillCircle( CLOCK_CENTER_X, CLOCK_CENTER_Y, 1, 0xFFFF );

        if( gOldHour != hour )
        {
            MATRIX_Printf( FONR_FREESERIFBOLDITALIC12PT7B, 1U, CLOCK_DIGITAL_HM_X, CLOCK_DIGITAL_HM_Y, 0x0U, "%02i", gOldHour);
            gOldHour = hour;
            MATRIX_Printf( FONR_FREESERIFBOLDITALIC12PT7B, 1U, CLOCK_DIGITAL_HM_X, CLOCK_DIGITAL_HM_Y, 0x7FF, "%02i", hour);
        }
        MATRIX_Printf( FONR_FREESERIFBOLDITALIC12PT7B, 1U, CLOCK_DIGITAL_HM_X + 25U, CLOCK_DIGITAL_HM_Y, 0x7FF, ":");
        if( gOldMin != minute )
        {
            MATRIX_Printf( FONR_FREESERIFBOLDITALIC12PT7B, 1U, CLOCK_DIGITAL_HM_X + 34U, CLOCK_DIGITAL_HM_Y, 0x0U, "%02i", gOldMin);
            gOldMin = minute;
            MATRIX_Printf( FONR_FREESERIFBOLDITALIC12PT7B, 1U, CLOCK_DIGITAL_HM_X + 34U, CLOCK_DIGITAL_HM_Y, 0x7FF, "%02i", minute);
        }
        if( gOldDay != day )
        {
            MATRIX_Printf( FONT_DEFAULT, 1U, CLOCK_DIGITAL_DATE_X, CLOCK_DIGITAL_DATE_Y, 0x0U, "%02i/%02i/20%02i", gOldDay, gOldMon, gOldYear);
            gOldDay = day;
            MATRIX_Printf( FONT_DEFAULT, 1U, CLOCK_DIGITAL_DATE_X, CLOCK_DIGITAL_DATE_Y, 0x7FF, "%02i/%02i/20%02i", day, month, year );
        }
    }
}

static inline void MATRIX_DisplayMonitor0(void)
{
    (void) gCurrentMonitor;

    if( gUpdateTimeFlag )
    {
        gUpdateTimeFlag = 0;

    }
}

static inline void MATRIX_DisplayMonitor1(void)
{
    (void) gCurrentMonitor;
}

static inline void MATRIX_DisplayMonitor2(void)
{
    (void) gCurrentMonitor;
}

static inline void MATRIX_DisplayMonitor3(void)
{
    (void) gCurrentMonitor;
}

static inline void MATRIX_DisplayMonitorRandom(void)
{
    (void) gCurrentMonitor;
}

static inline void CLOCK_BasicMonitor(void)
{
    IR_KeysLists nCurKey = IR_KEY_RESERVED;

    /* Avoid the warnings when it doesn't have any coding lines below */
    (void) nCurKey;

    switch( gCurrentMonitor )
    {
        case MONITOR_DISPLAY_ANALOG_CLOCK0:
            MATRIX_AnalogClockMode0();
            break;
        case MONITOR_DISPLAY_MON0:
            MATRIX_DisplayMonitor0();
            break;
        case MONITOR_DISPLAY_MON1:
            MATRIX_DisplayMonitor1();
            break;
        case MONITOR_DISPLAY_MON2:
            MATRIX_DisplayMonitor2();
            break;
        case MONITOR_DISPLAY_MON3:
            MATRIX_DisplayMonitor3();
            break;
        case MONITOR_DISPLAY_RANDOM:
            MATRIX_DisplayMonitorRandom();
            break;
        default:
            break;
    }
}

void DS3231_UpdateData( void )
{
    /* Read data to parse time informations */
    HAL_I2C_Mem_Read(&hi2c2,DS3231_ADDRESS,0,I2C_MEMADD_SIZE_8BIT,receive_data,7,1000);

    /* Raise global flag immediately to avoid the missing data at data cache */
    gUpdateTimeFlag = 1;

    /* Parse data */
    second=BCD2DEC(receive_data[0]);
    minute=BCD2DEC(receive_data[1]);
    hour=BCD2DEC(receive_data[2]);

    day=BCD2DEC(receive_data[3]);
    date=BCD2DEC(receive_data[4]);
    month=BCD2DEC(receive_data[5]);
    year= BCD2DEC(receive_data[6]);
}

uint8_t BCD2DEC(uint8_t data)
{
    return (data>>4)*10 + (data&0x0f);
}

uint8_t DEC2BCD(uint8_t data)
{
    return (data/10)<<4|(data%10);
}

void CLOCK_Setting( void )
{
    // extern const unsigned char gImage_ico_clock_64x64[8192];

    /* Avoid the warnings when it doesn't have any coding lines below */
    (void) 1U;
    MATRIX_TransitionEffect( TRANS_LEFT, EFFECT_FADE_OUT );
    CLOCK_ResetDefaultState();
    MATRIX_Printf( FONT_DEFAULT, 1U, 0U, 0U, 0x1485, "1. Time \n2. Fonts\n3. Lighting\n4. Strings\n5. Audio\n6. Video\n7. Exit");
    while (1)
    {
        /* code */
    }

}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C2_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  MX_TIM3_Init();
  MX_FATFS_Init();
  MX_LIBJPEG_Init();
  MX_SDIO_SD_Init();
  /* USER CODE BEGIN 2 */

    uint8_t u8Reg = 0U;

    HAL_I2C_Mem_Read( &hi2c2, DS3231_ADDRESS, DS3231_REG_CONTROL, I2C_MEMADD_SIZE_8BIT, &u8Reg, 1, 1000);

    /* clear all relevant bits to a known "off" state */
    u8Reg &= ~( DS3231_AIEMASK | DS3231_BBSQW );
    /* clear INTCN to enable clock SQW */
    u8Reg &= ~DS3231_INTCN;
    /* set enable int/sqw while in battery backup flag */
    u8Reg |= DS3231_BBSQW;

    HAL_I2C_Mem_Write( &hi2c2, DS3231_ADDRESS, DS3231_REG_CONTROL, I2C_MEMADD_SIZE_8BIT, &u8Reg, 1, 1000);

    // HAL_I2C_Mem_Write(&hi2c2, DS3231_ADDRESS, DS3231_REG_TIMEDATE, I2C_MEMADD_SIZE_8BIT, receive_data, 7, 1000);

    MATRIX_setBrightness( 80 );
    LL_TIM_CC_EnableChannel(TIM_OE, LL_TIM_CHANNEL_CH3);
    LL_TIM_OC_SetCompareCH3(TIM_OE, MATRIX_getBrightness());
    LL_TIM_EnableCounter(TIM_OE);

    LL_TIM_EnableIT_UPDATE(TIM_DAT);
    LL_TIM_EnableCounter(TIM_DAT);

    LL_TIM_CC_EnableChannel( TIM_IR, LL_TIM_CHANNEL_CH1 );
    LL_TIM_EnableIT_CC1( TIM_IR );
    LL_TIM_EnableCounter( TIM_IR );

    CLOCK_InitData();
        // MATRIX_Printf( FONT_DEFAULT, 1U, 0, 0, 0xF81F, "%04X ", FLASH_Read(1) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 25, 0, 0xF81F, "%04X ", FLASH_Read(2) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 50, 0, 0xF81F, "%04X ", FLASH_Read(3) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 75, 0, 0xF81F, "%04X ", FLASH_Read(4) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 100, 0, 0xF81F, "%04X ", FLASH_Read(5) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 0, 10, 0xF81F, "%04X ", FLASH_Read(6) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 25, 10, 0xF81F, "%04X ", FLASH_Read(7) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 50, 10, 0xF81F, "%04X ", FLASH_Read(8) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 75, 10, 0xF81F, "%04X ", FLASH_Read(9) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 100, 10, 0xF81F, "%04X ", FLASH_Read(10) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 0, 20, 0xF81F, "%04X ", FLASH_Read(11) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 25, 20, 0xF81F, "%04X ", FLASH_Read(12) );
        // MATRIX_Printf( FONT_DEFAULT, 1U, 50, 20, 0xF81F, "%04X ", FLASH_Read(13) );
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

    //
    // while(1);
    while( 1 )
    {
        // ON_LED();
        // // LL_mDelay(500);
        // OFF_LED();
        // LL_mDelay(500);
        CLOCK_BasicMonitor();

        switch( IR1838_GetCurrentKey() )
        {
            case IR_KEY_MENU:
                IR1838_SetCurrentKey( IR_KEY_RESERVED );
                CLOCK_Setting();
                break;
        default:
            break;
        }
        CLOCK_UpdateKeyCode();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  LL_FLASH_SetLatency(LL_FLASH_LATENCY_3);

  if(LL_FLASH_GetLatency() != LL_FLASH_LATENCY_3)
  {
  Error_Handler();  
  }
  LL_RCC_HSE_Enable();

   /* Wait till HSE is ready */
  while(LL_RCC_HSE_IsReady() != 1)
  {
    
  }
  LL_RCC_HSE_EnableCSS();
  LL_RCC_PLL_ConfigDomain_SYS(LL_RCC_PLLSOURCE_HSE, LL_RCC_PLLM_DIV_16, 288, LL_RCC_PLLP_DIV_2);
  LL_RCC_PLL_ConfigDomain_48M(LL_RCC_PLLSOURCE_HSE, LL_RCC_PLLM_DIV_16, 288, LL_RCC_PLLQ_DIV_6);
  LL_RCC_PLL_Enable();

   /* Wait till PLL is ready */
  while(LL_RCC_PLL_IsReady() != 1)
  {
    
  }
  LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);
  LL_RCC_SetAPB1Prescaler(LL_RCC_APB1_DIV_4);
  LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_2);
  LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_PLL);

   /* Wait till System clock is ready */
  while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_PLL)
  {
  
  }
  LL_SetSystemCoreClock(144000000);
}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 400000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief SDIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_SDIO_SD_Init(void)
{

  /* USER CODE BEGIN SDIO_Init 0 */

  /* USER CODE END SDIO_Init 0 */

  /* USER CODE BEGIN SDIO_Init 1 */

  /* USER CODE END SDIO_Init 1 */
  hsd.Instance = SDIO;
  hsd.Init.ClockEdge = SDIO_CLOCK_EDGE_RISING;
  hsd.Init.ClockBypass = SDIO_CLOCK_BYPASS_DISABLE;
  hsd.Init.ClockPowerSave = SDIO_CLOCK_POWER_SAVE_DISABLE;
  hsd.Init.BusWide = SDIO_BUS_WIDE_1B;
  hsd.Init.HardwareFlowControl = SDIO_HARDWARE_FLOW_CONTROL_ENABLE;
  hsd.Init.ClockDiv = 0;
  /* USER CODE BEGIN SDIO_Init 2 */

  /* USER CODE END SDIO_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM3);
  
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOC);
  /**TIM3 GPIO Configuration  
  PC6   ------> TIM3_CH1 
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_6;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  GPIO_InitStruct.Alternate = LL_GPIO_AF_2;
  LL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* TIM3 interrupt Init */
  NVIC_SetPriority(TIM3_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),3, 0));
  NVIC_EnableIRQ(TIM3_IRQn);

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  TIM_InitStruct.Prescaler = 79;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 65535;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  LL_TIM_Init(TIM3, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM3);
  LL_TIM_SetClockSource(TIM3, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_SetTriggerOutput(TIM3, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM3);
  LL_TIM_IC_SetActiveInput(TIM3, LL_TIM_CHANNEL_CH1, LL_TIM_ACTIVEINPUT_DIRECTTI);
  LL_TIM_IC_SetPrescaler(TIM3, LL_TIM_CHANNEL_CH1, LL_TIM_ICPSC_DIV1);
  LL_TIM_IC_SetFilter(TIM3, LL_TIM_CHANNEL_CH1, LL_TIM_IC_FILTER_FDIV1);
  LL_TIM_IC_SetPolarity(TIM3, LL_TIM_CHANNEL_CH1, LL_TIM_IC_POLARITY_FALLING);
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM4);

  /* TIM4 interrupt Init */
  NVIC_SetPriority(TIM4_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),4, 0));
  NVIC_EnableIRQ(TIM4_IRQn);

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  TIM_InitStruct.Prescaler = 0;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 60;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  LL_TIM_Init(TIM4, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM4);
  LL_TIM_SetClockSource(TIM4, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_SetTriggerOutput(TIM4, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM4);
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};
  LL_TIM_OC_InitTypeDef TIM_OC_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM5);

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  TIM_InitStruct.Prescaler = 1;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 100;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  LL_TIM_Init(TIM5, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM5);
  LL_TIM_SetClockSource(TIM5, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_OC_EnablePreload(TIM5, LL_TIM_CHANNEL_CH3);
  TIM_OC_InitStruct.OCMode = LL_TIM_OCMODE_PWM1;
  TIM_OC_InitStruct.OCState = LL_TIM_OCSTATE_DISABLE;
  TIM_OC_InitStruct.OCNState = LL_TIM_OCSTATE_DISABLE;
  TIM_OC_InitStruct.CompareValue = 0;
  TIM_OC_InitStruct.OCPolarity = LL_TIM_OCPOLARITY_LOW;
  LL_TIM_OC_Init(TIM5, LL_TIM_CHANNEL_CH3, &TIM_OC_InitStruct);
  LL_TIM_OC_DisableFast(TIM5, LL_TIM_CHANNEL_CH3);
  LL_TIM_SetTriggerOutput(TIM5, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM5);
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
  /**TIM5 GPIO Configuration  
  PA2   ------> TIM5_CH3 
  */
  GPIO_InitStruct.Pin = OE_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  GPIO_InitStruct.Alternate = LL_GPIO_AF_2;
  LL_GPIO_Init(OE_GPIO_Port, &GPIO_InitStruct);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_EXTI_InitTypeDef EXTI_InitStruct = {0};
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOH);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOC);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOB);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOD);

  /**/
  LL_GPIO_ResetOutputPin(LA_GPIO_Port, LA_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LB_GPIO_Port, LB_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LC_GPIO_Port, LC_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LD_GPIO_Port, LD_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LED_GPIO_Port, LED_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LE_GPIO_Port, LE_Pin);

  /**/
  LL_GPIO_ResetOutputPin(R2_GPIO_Port, R2_Pin);

  /**/
  LL_GPIO_ResetOutputPin(G2_GPIO_Port, G2_Pin);

  /**/
  LL_GPIO_ResetOutputPin(B2_GPIO_Port, B2_Pin);

  /**/
  LL_GPIO_ResetOutputPin(B4_GPIO_Port, B4_Pin);

  /**/
  LL_GPIO_ResetOutputPin(G4_GPIO_Port, G4_Pin);

  /**/
  LL_GPIO_ResetOutputPin(R1_GPIO_Port, R1_Pin);

  /**/
  LL_GPIO_ResetOutputPin(B1_GPIO_Port, B1_Pin);

  /**/
  LL_GPIO_ResetOutputPin(G1_GPIO_Port, G1_Pin);

  /**/
  LL_GPIO_ResetOutputPin(R3_GPIO_Port, R3_Pin);

  /**/
  LL_GPIO_ResetOutputPin(G3_GPIO_Port, G3_Pin);

  /**/
  LL_GPIO_ResetOutputPin(B3_GPIO_Port, B3_Pin);

  /**/
  LL_GPIO_ResetOutputPin(R4_GPIO_Port, R4_Pin);

  /**/
  LL_GPIO_SetOutputPin(CLK_GPIO_Port, CLK_Pin);

  /**/
  LL_GPIO_SetOutputPin(LAT_GPIO_Port, LAT_Pin);

  /**/
  GPIO_InitStruct.Pin = LA_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LA_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LB_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LB_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LC_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LC_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LD_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LD_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = CLK_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(CLK_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LAT_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LAT_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = UPD_KEY_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(UPD_KEY_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = TBD_BT_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(TBD_BT_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LE_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LE_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = R2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(R2_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = G2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(G2_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = B2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(B2_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = B4_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(B4_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = G4_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(G4_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = SD_CD_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(SD_CD_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = R1_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(R1_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = G1_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(G1_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = R3_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(R3_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = G3_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(G3_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = B3_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(B3_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = R4_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(R4_GPIO_Port, &GPIO_InitStruct);

  /**/
  LL_SYSCFG_SetEXTISource(LL_SYSCFG_EXTI_PORTC, LL_SYSCFG_EXTI_LINE7);

  /**/
  LL_GPIO_SetPinPull(GPIOC, LL_GPIO_PIN_7, LL_GPIO_PULL_NO);

  /**/
  LL_GPIO_SetPinMode(GPIOC, LL_GPIO_PIN_7, LL_GPIO_MODE_INPUT);

  /**/
  EXTI_InitStruct.Line_0_31 = LL_EXTI_LINE_7;
  EXTI_InitStruct.LineCommand = ENABLE;
  EXTI_InitStruct.Mode = LL_EXTI_MODE_IT;
  EXTI_InitStruct.Trigger = LL_EXTI_TRIGGER_RISING;
  LL_EXTI_Init(&EXTI_InitStruct);

  /* EXTI interrupt init*/
  NVIC_SetPriority(EXTI9_5_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),5, 0));
  NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
